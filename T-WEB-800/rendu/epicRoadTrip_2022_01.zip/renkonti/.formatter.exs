[
  inputs: ["mix.exs", "config/*.exs"],
  subdirectories: ["apps/*"]
]
