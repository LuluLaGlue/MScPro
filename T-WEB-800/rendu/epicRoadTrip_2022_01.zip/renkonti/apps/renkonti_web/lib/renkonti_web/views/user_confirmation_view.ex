defmodule RenkontiWeb.UserConfirmationView do
  use RenkontiWeb, :view
end
