defmodule RenkontiWeb.UserRegistrationView do
  use RenkontiWeb, :view
end
