defmodule RenkontiWeb.LayoutView do
  use RenkontiWeb, :view
end
