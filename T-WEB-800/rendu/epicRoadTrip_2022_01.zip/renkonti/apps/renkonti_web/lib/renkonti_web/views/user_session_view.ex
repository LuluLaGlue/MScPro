defmodule RenkontiWeb.UserSessionView do
  use RenkontiWeb, :view
end
