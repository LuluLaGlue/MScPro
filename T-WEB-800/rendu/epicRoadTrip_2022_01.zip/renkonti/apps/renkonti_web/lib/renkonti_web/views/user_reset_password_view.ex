defmodule RenkontiWeb.UserResetPasswordView do
  use RenkontiWeb, :view
end
