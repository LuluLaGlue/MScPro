defmodule RenkontiWeb.UserSettingsView do
  use RenkontiWeb, :view
end
