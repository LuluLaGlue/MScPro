defmodule RenkontiWeb.PageLiveTest do
  use RenkontiWeb.ConnCase

  import Phoenix.LiveViewTest
end
