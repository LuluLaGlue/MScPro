[
  import_deps: [:ecto_sql],
  inputs: ["*.exs"]
]
