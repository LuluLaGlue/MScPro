defmodule Renkonti.Repo.Migrations.CreateEvents do
  use Ecto.Migration

  def change do
    create table(:events, primary_key: false) do
      add :id, :binary_id, primary_key: true
      add :title, :string
      add :startAt, :date
      add :endAt, :date
      add :address, :string
      add :description, :string
      add :userId, references(:users, on_delete: :nothing, type: :binary_id)
      add :ownerId, references(:users, on_delete: :nothing, type: :binary_id)
      add :locationId, references(:countries, on_delete: :nothing, type: :binary_id)

      timestamps()
    end

    create index(:events, [:userId])
    create index(:events, [:ownerId])
    create index(:events, [:locationId])
  end
end
