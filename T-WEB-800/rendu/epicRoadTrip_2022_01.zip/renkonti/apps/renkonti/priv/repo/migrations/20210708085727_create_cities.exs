defmodule Renkonti.Repo.Migrations.CreateCities do
  use Ecto.Migration

  def change do
    create table(:cities, primary_key: false) do
      add :id, :binary_id, primary_key: true
      add :name, :string
      add :zipCode, :string
      add :countryId, references(:countries, on_delete: :nothing, type: :binary_id)

      timestamps()
    end

    create index(:cities, [:countryId])
  end
end
