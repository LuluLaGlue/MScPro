defmodule Renkonti.Feeds.Rss do
end
