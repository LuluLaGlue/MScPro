defmodule Renkonti.Events.Event do
  use Ecto.Schema
  import Ecto.Changeset

  @primary_key {:id, :binary_id, autogenerate: true}
  @foreign_key_type :binary_id
  schema "events" do
    field :address, :string
    field :description, :string
    field :endAt, :date
    field :startAt, :date
    field :title, :string
    field :userId, :binary_id
    field :ownerId, :binary_id
    field :locationId, :binary_id

    timestamps()
  end

  @doc false
  def changeset(event, attrs) do
    event
    |> cast(attrs, [:title, :startAt, :endAt, :address, :description])
    |> validate_required([:title, :startAt, :endAt, :address, :description])
  end
end
