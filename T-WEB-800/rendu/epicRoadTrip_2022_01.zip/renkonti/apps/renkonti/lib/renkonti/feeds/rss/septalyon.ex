defmodule Renkonti.Feeds.Rss.Septalyon do
  use Tesla

  alias Quinn

  plug Tesla.Middleware.BaseUrl, "https://7alyon.com"

  def get_feed() do
    {:ok, response} = get("/feed/")
    response.body
  end

  def parse_feed(xml) do
    Quinn.parse(xml)
    |> List.first
    |> Map.get(:value)
    |> List.first
    |> Map.get(:value)
  end

  def get_items(xml_body) do
    xml_body
    |> Enum.filter(fn x -> Map.get(x, :name) == :item end)
  end

  def get_titles(items) do
    items
    |> Enum.map(fn x -> x.value end)
    |> Enum.map(fn x -> get_title(x) end)
  end

  def get_title(item_value) do
    item_value
    |> Enum.filter(fn x -> x.name == :title end)
    |> Enum.map(fn x -> List.first(x).value end)
  end

  def read_feed() do
    get_feed()
    |> parse_feed
  end
end
