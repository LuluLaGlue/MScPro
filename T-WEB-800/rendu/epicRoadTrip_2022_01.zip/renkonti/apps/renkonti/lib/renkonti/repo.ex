defmodule Renkonti.Repo do
  use Ecto.Repo,
    otp_app: :renkonti,
    adapter: Ecto.Adapters.Postgres
end
