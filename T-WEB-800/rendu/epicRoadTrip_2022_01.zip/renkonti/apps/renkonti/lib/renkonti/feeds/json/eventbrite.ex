defmodule Renkonti.Feeds.Json.Evenbrite do
  use Tesla

  plug Tesla.Middleware.BaseUrl, "https://www.eventbriteapi.com/v3"
  plug Tesla.Middleware.Headers, [{"Authorization", "Bearer JZ22U6H47DGMFALF6USS"}]
  plug Tesla.Middleware.JSON
  plug Tesla.Middleware.FollowRedirects

  def query(path) do
    {:ok, response} = get(path)
    response
  end

end
