defmodule Renkonti.CitiesTest do
  use Renkonti.DataCase

  alias Renkonti.Cities

  describe "cities" do
    alias Renkonti.Cities.City

    @valid_attrs %{name: "some name", zipCode: "some zipCode"}
    @update_attrs %{name: "some updated name", zipCode: "some updated zipCode"}
    @invalid_attrs %{name: nil, zipCode: nil}

    def city_fixture(attrs \\ %{}) do
      {:ok, city} =
        attrs
        |> Enum.into(@valid_attrs)
        |> Cities.create_city()

      city
    end

    test "list_cities/0 returns all cities" do
      city = city_fixture()
      assert Cities.list_cities() == [city]
    end

    test "get_city!/1 returns the city with given id" do
      city = city_fixture()
      assert Cities.get_city!(city.id) == city
    end

    test "create_city/1 with valid data creates a city" do
      assert {:ok, %City{} = city} = Cities.create_city(@valid_attrs)
      assert city.name == "some name"
      assert city.zipCode == "some zipCode"
    end

    test "create_city/1 with invalid data returns error changeset" do
      assert {:error, %Ecto.Changeset{}} = Cities.create_city(@invalid_attrs)
    end

    test "update_city/2 with valid data updates the city" do
      city = city_fixture()
      assert {:ok, %City{} = city} = Cities.update_city(city, @update_attrs)
      assert city.name == "some updated name"
      assert city.zipCode == "some updated zipCode"
    end

    test "update_city/2 with invalid data returns error changeset" do
      city = city_fixture()
      assert {:error, %Ecto.Changeset{}} = Cities.update_city(city, @invalid_attrs)
      assert city == Cities.get_city!(city.id)
    end

    test "delete_city/1 deletes the city" do
      city = city_fixture()
      assert {:ok, %City{}} = Cities.delete_city(city)
      assert_raise Ecto.NoResultsError, fn -> Cities.get_city!(city.id) end
    end

    test "change_city/1 returns a city changeset" do
      city = city_fixture()
      assert %Ecto.Changeset{} = Cities.change_city(city)
    end
  end
end
