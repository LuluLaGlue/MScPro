ExUnit.start()
Ecto.Adapters.SQL.Sandbox.mode(Renkonti.Repo, :manual)
