# Cellsus weather forecast web app

## Launch the server with

```
nodemon server
```
