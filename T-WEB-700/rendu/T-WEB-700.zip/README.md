# T-WEB-700
### To run api:
`cd ./api && npm install && node app.js`
### To run front:
`cd ./thecountof_money && npm install && npm start`