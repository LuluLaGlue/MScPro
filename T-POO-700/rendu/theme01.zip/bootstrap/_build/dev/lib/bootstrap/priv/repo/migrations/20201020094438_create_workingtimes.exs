defmodule Bootstrap.Repo.Migrations.CreateWorkingtimes do
  use Ecto.Migration

  def change do
    create table(:workingtimes) do
      add :end, :naive_datetime
      add :start, :naive_datetime
      add :is_active, :boolean, default: false, null: false
      add :user_id, references(:user, on_delete: :nothing)

      timestamps()
    end

    create index(:workingtimes, [:user_id])
  end
end
