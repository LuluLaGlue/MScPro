defmodule Bootstrap.Repo.Migrations.CreateUser do
  use Ecto.Migration

  def change do
    create table(:user) do
      add :email, :string
      add :is_active, :boolean, default: false, null: false
      add :username, :string
      # add :id, :uuid

      timestamps()
    end

    create unique_index(:user, [:email])
    create unique_index(:user, [:username])
  end
end
