defmodule Joken.AlgorithmError do
  @moduledoc false
  @doc false
  defexception [:message]
end
