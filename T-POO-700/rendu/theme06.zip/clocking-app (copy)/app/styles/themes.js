import { StyleSheet, Dimensions} from 'react-native';

const { width, height } = Dimensions.get('screen');

const themes = StyleSheet.create({
    btnPrimary: {
        backgroundColor: "#F52D56",
        padding: 15,
        fontSize: 15,
        fontWeight: 'bold',
        borderWidth: 1,
        borderRadius: 2,
        borderColor: '#F52D56',
        borderBottomWidth: 0,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.8,
        shadowRadius: 2,
        elevation: 3,
        marginLeft: 5,
        marginRight: 5,
        marginTop: 30,
        marginBottom: 50,
        borderRadius: 5,
        alignSelf: "center",
        textAlign: 'center'
    },
    plusIconHeader: {
        zIndex: 10000,
        position: 'absolute',
        top: 33,
        width: 70,
        height: 70,
    },
    heartIconHeader: {
        zIndex: 10000,
        position: 'absolute',
        top: 35,
        width: 70, 
        height: 70, 
        right: 0
    },
    headerText: { 
        textAlign: "center", 
        fontSize: 30, 
        fontFamily: "Ubuntu", 
        color: "white", 
        marginTop: 25, 
        marginBottom: 0
    },
    pillsButton : {
        backgroundColor: "#F52D56",
        fontWeight: 'bold',
        borderColor: '#F52D56',
        borderBottomWidth: 0,
        shadowColor: '#000',
        marginLeft: 5,
        marginRight: 5,
        borderRadius: 5,
        alignSelf: "center",
        textAlign: 'center',
        borderRadius: 100, 
        fontSize: 10,
        padding: 10, 
        marginTop: 1
    },
    pillsButtonText: { 
        color: 'white',
        fontWeight: "bold", 
        textAlign: "center", 
        textTransform: "uppercase" 
    },
    pillsButtonSecondary : {
        backgroundColor: "white",
        fontWeight: 'bold',
        borderColor: '#F52D56',
        borderWidth: 2,
        shadowColor: '#000',
        marginLeft: 5,
        marginRight: 5,
        borderRadius: 5,
        alignSelf: "center",
        textAlign: 'center',
        borderRadius: 100, 
        fontSize: 10,
        padding: 10, 
        marginTop: 1
    },
    pillsButtonSecondaryText: { 
        color: '#F52D56',
        fontWeight: "bold", 
        textAlign: "center", 
        textTransform: "uppercase" 
    },
    pillsButtonYellowOutline : {
        backgroundColor: "white",
        fontWeight: 'bold',
        borderColor: '#ffbd17',
        borderWidth: 2,
        shadowColor: '#000',
        marginLeft: 5,
        marginRight: 5,
        borderRadius: 5,
        textAlign: 'center',
        borderRadius: 100, 
        fontSize: 10,
        padding: 10, 
        marginTop: 1,
        width: 200
    },
    pillsButtonYellowOutlineText: { 
        color: '#ffbd17',
        fontWeight: "bold", 
        textAlign: "center", 
        textTransform: "uppercase" 
    },
    receiptCard: {
        shadowColor: '#000',
        shadowOffset: { width: 10, height: 2 },
        shadowOpacity: 0.8,
        shadowRadius: 10,
        elevation: 3,
        borderRadius: 10
    },
    cardImage: {
        height: 200,
        backgroundColor: 'white'
    },
    cardImageSearch: {
        minHeight: width * 0.30,
        backgroundColor: 'white'
    },
    cardAction: {
        padding: 0,
        display: 'flex',
        height: 45
    },
    cardContent: {
        fontSize: 15, 
        fontWeight: 'bold', 
        fontFamily: "Ubuntu",
        color: "#262628"
    },
    cardSubtitle: {
        marginTop: -15,
        fontSize: 13, 
        textTransform: 'capitalize',
        color: 'lightgrey',
    },
    cardButton: {
        position: 'absolute',
        marginLeft: '55%'
    },
});

export default themes;
