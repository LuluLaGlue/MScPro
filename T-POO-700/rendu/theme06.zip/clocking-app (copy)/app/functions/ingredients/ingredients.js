let categoryList = [
{
    "name" : "Biscuits",
},
{
    "name" : "Chocolats",
},
{
    "name" : "Yaourts",
},
{
    "name" : "Pains",
},
{
    "name" : "Poulets",
},
{
    "name" : "Jambons",
},
{
    "name" : "Huiles",
},
{
    "name" : "Céréales pour petit-déjeuner",
},
{
    "name" : "Miels",
},
{
    "name" : "Bonbons",
},
{
    "name" : "Chips",
},
{
    "name" : "Saucissons",
},
{
    "name" : "Thés",
},
{
    "name" : "Bières",
},
{
    "name" : "Laits",
},
{
    "name" : "Huiles d'olive",
},
{
    "name" : "Sodas",
},
{
    "name" : "Cafés",
},
{
    "name" : "Foies gras",
},
{
    "name" : "Moutardes",
},
{
    "name" : "Pickles",
},
{
    "name" : "Rillettes",
},
{
    "name" : "Comté",
},
{
    "name" : "Saumons",
},
{
    "name" : "Brioches",
},
{
    "name" : "Thons",
},
{
    "name" : "Sauces tomate",
},
{
    "name" : "Bœuf",
},
{
    "name" : "Compotes de pomme",
},
{
    "name" : "Dindes",
},
{
    "name" : "Pâtes à tartiner",
},
{
    "name" : "Porc",
},
{
    "name" : "Mueslis",
},
{
    "name" : "Madeleines",
},
{
    "name" : "Saumons fumés",
},
{
    "name" : "Milkfat",
},
{
    "name" : "Beurres",
},
{
    "name" : "Jambons crus",
},
{
    "name" : "Sardines",
},
{
    "name" : "Surimi",
},
{
    "name" : "Vinaigres",
},
{
    "name" : "Riz",
},
{
    "name" : "Œufs",
},
{
    "name" : "Jus d'orange",
},
{
    "name" : "Olives",
},
{
    "name" : "Emmentals",
},
{
    "name" : "Farines",
},
{
    "name" : "Mayonnaises",
},
{
    "name" : "Jus de pomme",
},
{
    "name" : "Pâtes de blé dur",
},
{
    "name" : "Cream cheeses",
},
{
    "name" : "Fromages de chèvre",
},
{
    "name" : "Escalopes de dinde",
},
{
    "name" : "Nouilles",
},
{
    "name" : "Confitures de fraises",
},
{
    "name" : "Pains de mie",
},
{
    "name" : "Sucres",
},
{
    "name" : "Fromages blancs",
},
{
    "name" : "Amandes",
},
{
    "name" : "Steaks hachés",
},
{
    "name" : "Ravioli",
},
{
    "name" : "Bananes",
},
{
    "name" : "Champignons",
},
{
    "name" : "Pâtés de porc",
},
{
    "name" : "Terrines de campagne",
},
{
    "name" : "Ketchup",
},
{
    "name" : "Lentilles",
},
{
    "name" : "Sauces pour pâtes",
},
{
    "name" : "Fromages à tartiner",
},
{
    "name" : "Vinaigrettes",
},
{
    "name" : "Tomates",
},
{
    "name" : "Maquereaux",
},
{
    "name" : "Tapenades",
},
{
    "name" : "Spaghetti",
},
{
    "name" : "Margarines",
},
{
    "name" : "Crevettes",
},
{
    "name" : "Purées de tomates",
},
{
    "name" : "Sauces Pesto Rosso",
},
{
    "name" : "Fraises",
},
{
    "name" : "Jus de tomates",
},
{
    "name" : "Cheddars",
},
{
    "name" : "Confitures de mûres",
},
{
    "name" : "Gorgonzolas",
},
{
    "name" : "Rillettes de poulet",
},
{
    "name" : "Abats",
},
{
    "name" : "Mozzarella",
},
{
    "name" : "Cidres",
},
{
    "name" : "Houmous",
},
{
    "name" : "Cacahuètes",
},
{
    "name" : "Noix de cajou",
},
{
    "name" : "Reblochons",
},
{
    "name" : "Camemberts",
},
{
    "name" : "Confitures de framboises",
},
{
    "name" : "Nougats",
},
{
    "name" : "Haricots verts",
},
{
    "name" : "Canards",
},
{
    "name" : "Goudas",
},
{
    "name" : "Haricots rouges",
},
{
    "name" : "Confitures de mirabelles",
},
{
    "name" : "Confitures d'orange",
},
{
    "name" : "Confitures de rhubarbe",
},
{
    "name" : "Fourme d'Ambert",
},
{
    "name" : "Kiwis",
},
{
    "name" : "Rillettes de sardine",
},
{
    "name" : "Terrines de lapin",
},
{
    "name" : "Viandes de veau",
},
{
    "name" : "Purées d'amande",
},
{
    "name" : "Rillettes de la Sarthe",
},
{
    "name" : "Knacks industrielles",
},
{
    "name" : "Pains Burger",
},
{
    "name" : "Mandarines",
},
{
    "name" : "Gingembre",
},
{
    "name" : "Brocolis",
},
{
    "name" : "Framboises",
},
{
    "name" : "Tomme des Pyrénées",
},
{
    "name" : "Chipolatas aux herbes",
},
{
    "name" : "Chapelure",
},
{
    "name" : "Rillettes du Mans",
},
{
    "name" : "Pains Bagel",
},
{
    "name" : "Tomme de Savoie",
},
{
    "name" : "Lardons de porc",
},
{
    "name" : "Haricots",
},
{
    "name" : "Chocolats blancs",
},
{
    "name" : "Emmentals râpés",
},
{
    "name" : "Caramels",
},
{
    "name" : "Biscottes",
},
{
    "name" : "Rillettes de canard",
},
{
    "name" : "Gnocchi",
},
{
    "name" : "Confitures de figues",
},
{
    "name" : "Quenelles",
},
{
    "name" : "Cornichons",
},
{
    "name" : "Confitures de myrtilles",
},
{
    "name" : "Chicorée soluble",
},
{
    "name" : "Sauces béarnaises",
},
{
    "name" : "Sauces au curry",
},
{
    "name" : "Blés",
},
{
    "name" : "Sauces samouraï",
},
{
    "name" : "Mascarpone",
},
{
    "name" : "Panna cottas",
},
{
    "name" : "Herbes de Provence",
},
{
    "name" : "Jus de grenade",
},
{
    "name" : "Sorbets à la fraise",
},
{
    "name" : "Gruau",
},
{
    "name" : "Choux-fleurs",
},
{
    "name" : "Anchois",
},
{
    "name" : "Pâtes d'amande",
},
{
    "name" : "Sauces burger",
},
{
    "name" : "Sauces chili",
},
{
    "name" : "Sorbets à la framboise",
},
{
    "name" : "Raisins",
},
{
    "name" : "Jus de carotte",
},
{
    "name" : "Sauces Arrabiata",
},
{
    "name" : "Colins",
},
{
    "name" : "Avocats",
},
{
    "name" : "Burrata",
},
{
    "name": "Bœufs"
},
{
    "name" : "Noix de coco",
},
{
    "name" : "Sauces tartare",
},
{
    "name" : "Bûche de chèvre",
},
{
    "name" : "Gruau de blé",
},
{
    "name" : "Boulghours",
},
{
    "name" : "Choux de Bruxelles",
},
{
    "name" : "Sirops de pêche",
},
{
    "name" : "Chia",
},
{
    "name" : "Falafels",
},
{
    "name" : "Saint-Marcellin",
},
{
    "name" : "Pois",
},
{
    "name" : "Sorbets au citron",
},
{
    "name" : "Baguettes",
},
{
    "name" : "Dattes",
},
{
    "name" : "Crèmes de marrons",
},
{
    "name" : "Épinards",
},
{
    "name" : "Truites",
},
{
    "name" : "Poissons panés",
},
{
    "name" : "Harengs",
},
{
    "name" : "Limonades",
},
{
    "name" : "Chorizo",
},
{
    "name" : "Frites",
},
{
    "name" : "Bries",
},
{
    "name" : "Poivres",
},
{
    "name" : "Morbiers",
},
{
    "name" : "Corn-flakes",
},
{
    "name" : "Levures",
},
{
    "name" : "Curry",
},
{
    "name" : "Curcuma",
},
{
    "name" : "Rillettes d'oie",
},
{
    "name" : "Calamars",
},
{
    "name" : "Coulis de framboise",
},
{
    "name" : "Clémentines",
},
{
    "name" : "Sirops de cassis",
},
{
    "name" : "Courgettes",
},
{
    "name" : "Mâches",
},
{
    "name" : "Sirops de framboise",
},
{
    "name" : "Maroilles",
},
{
    "name" : "Jus de poire",
},
{
    "name" : "Laitues",
},
{
    "name" : "Citrons",
},
{
    "name" : "Jus de clémentine",
},
{
    "name" : "Pruneaux",
},
{
    "name" : "Ratatouilles",
},
{
    "name" : "Crèmes fraîches",
},
{
    "name" : "Noix",
},
{
    "name" : "Carottes",
},
{
    "name" : "Pistaches",
},
{
    "name" : "Sauces à la viande",
},
{
    "name" : "Popcorn",
},
{
    "name" : "Raclettes",
},
{
    "name" : "Sauces barbecue",
},
{
    "name" : "Magrets de canard",
},
{
    "name" : "Sauces au soja",
},
{
    "name" : "Moules",
},
{
    "name" : "Semoules de blé",
},
{
    "name" : "Salades vertes",
},
{
    "name" : "Gaspacho",
},
{
    "name" : "Saucisses de Strasbourg",
},
{
    "name" : "Châtaignes",
},
{
    "name" : "Sirops de pamplemousse",
},
{
    "name" : "Oranges",
},
{
    "name" : "Gélifiants",
},
{
    "name" : "Terrines de saumon",
},
{
    "name" : "Cappuccino en poudre",
},
{
    "name" : "Saucisses végétales",
},
{
    "name" : "Ras el hanout",
},
{
    "name" : "Myrtilles",
},
{
    "name" : "Caviars",
},
{
    "name" : "Jus de raisin",
},
{
    "name" : "Pestos au basilic",
},
{
    "name" : "Purées de pommes de terre",
},
{
    "name" : "Saucisses de Toulouse",
},
{
    "name" : "Confitures de cerises",
},
{
    "name" : "Pommes",
},
{
    "name" : "Pommes de terre",
},
{
    "name" : "Rillettes de thon",
},
{
    "name" : "Quinoa",
},
{
    "name" : "Jus d'ananas",
},
{
    "name" : "Sauces bolognaises",
},
{
    "name" : "Jus de citron",
},
{
    "name" : "Artichauts",
},
{
    "name" : "Fromages fondus",
},
{
    "name" : "Mimolettes",
},
{
    "name" : "Confitures de prunes",
},
{
    "name" : "Beaufort",
},
{
    "name" : "Salamis",
},
{
    "name" : "Roqueforts",
},
{
    "name" : "Marmelades",
},
{
    "name" : "Pont-l'évêque",
},
{
    "name" : "Basilic",
},
{
    "name" : "Paprika",
},
{
    "name" : "Abricots",
},
{
    "name" : "Lins",
},
{
    "name" : "Sauces béchamel",
},
{
    "name" : "Vodkas",
},
{
    "name" : "Mont d'Or",
},
{
    "name" : "Persil",
},
{
    "name" : "Échalotes",
},
{
    "name" : "Asperges vertes",
},
{
    "name" : "Saint-Félicien",
},
{
    "name" : "Chouquettes",
},
{
    "name" : "Sauces aigre-douces",
},
{
    "name" : "Cumin",
},
{
    "name" : "Sauces aux champignons",
},
{
    "name" : "Ricotta",
},
{
    "name" : "Melons",
},
{
    "name" : "Sirops de violette",
},
{
    "name" : "Munsters",
},
{
    "name" : "Glaces au caramel",
},
{
    "name" : "Gelées de groseilles",
},
{
    "name" : "Thym",
},
{
    "name" : "Pastis",
},
{
    "name" : "Haricots blancs",
},
{
    "name" : "Viandes d'agneau",
},
{
    "name" : "Confits d'oignons",
},
{
    "name" : "Blancs de dinde",
},
{
    "name" : "Taramas",
},
{
    "name" : "Bacon",
},
{
    "name" : "Champignons de Paris",
},
{
    "name" : "Huiles de tournesol",
},
{
    "name" : "Oignons",
},
{
    "name" : "Champagnes",
},
{
    "name" : "Sirops de grenadine",
},
{
    "name" : "Sirops de menthe",
},
{
    "name" : "Merguez",
},
{
    "name" : "Harissas",
},
{
    "name" : "Choux rouges",
},
{
    "name" : "Sauces au fromage",
},
{
    "name" : "Feta",
},
{
    "name" : "Pois chiches",
},
{
    "name" : "Noisettes",
},
{
    "name" : "Coquillettes",
},
{
    "name" : "Cantal",
},
{
    "name" : "Rosettes",
},
{
    "name" : "Morues",
},
{
    "name" : "Cacaos en poudre",
},
{
    "name" : "Rillettes de saumon",
},
{
    "name" : "Agar-agar",
},
{
    "name" : "Eaux gazeuses aromatisées",
},
{
    "name" : "Filets mignons de porc",
},
{
    "name" : "Sauces caesar",
},
{
    "name" : "Sorbets à la mangue",
},
{
    "name" : "Endives",
},
{
    "name" : "Confitures d'églantines",
},
{
    "name" : "Noix de Saint-Jacques",
},
{
    "name" : "Soja",
},
{
    "name" : "Soupes de tomate",
},
{
    "name" : "Radis",
},
{
    "name" : "Jus de pruneaux",
},
{
    "name" : "Gélatine",
},
{
    "name" : "Pêches",
},
{
    "name" : "Ciboulette",
},
{
    "name" : "Poireaux",
},
{
    "name" : "Sauces provençales",
},
{
    "name" : "Mangues",
},
{
    "name" : "Algues nori",
},
{
    "name" : "Purées de carottes",
},
{
    "name" : "Bleus d'Auvergne",
},
{
    "name" : "Chaource",
},
{
    "name" : "Têtes de Moine",
},
{
    "name" : "Origan",
},
{
    "name" : "Sirops à l'anis",
},
{
    "name" : "Neufchâtel",
},
{
    "name" : "Guimauves",
},
{
    "name" : "Confitures de lait",
},
{
    "name" : "Blinis",
},
{
    "name" : "Côtes de porc",
},
{
    "name" : "Sirops de fraise",
},
{
    "name" : "Piments",
},
{
    "name" : "Ravioles",
},
{
    "name" : "Betteraves",
},
{
    "name" : "Ail",
},
{
    "name" : "Crèmes liquides",
},
{
    "name" : "Marrons glacés",
},
{
    "name" : "Andouillettes",
},
{
    "name" : "Jus de pamplemousse",
},
{
    "name" : "Tofu",
},
{
    "name" : "Saint-nectaire",
},
{
    "name" : "Pâtés de foie",
},
{
    "name" : "Sauces Teriyaki",
},
{
    "name" : "Cabécous",
},
{
    "name" : "Sirops d'orgeat",
},
{
    "name" : "Rillettes de truite",
},
{
    "name" : "Grenouille",
},
{
    "name" : "Halloumi",
},
{
    "name" : "Figues",
},
{
    "name" : "Pâtés de canard",
},
{
    "name" : "Carpaccio de boeuf",
},
{
    "name" : "Vins mousseux",
},
{
    "name" : "Sauces crudités",
},
{
    "name" : "Courges",
},
{
    "name" : "Sainte-Maure de Touraine",
},
{
    "name" : "Pains Pita",
},
{
    "name" : "Bretzels",
},
{
    "name" : "Guacamoles",
},
{
    "name" : "Ananas",
},
{
    "name" : "Whiskys",
},
{
    "name" : "Mousses de canard",
},
{
    "name" : "Andouilles",
},
{
    "name" : "Concentrés de tomates",
},
{
    "name" : "Sirops d'agave",
},
{
    "name" : "Sauces au poivre",
},
{
    "name" : "Coulommiers",
},
{
    "name" : "Rhums",
},
{
    "name" : "Maïs",
},
{
    "name" : "Prunes",
},
{
    "name" : "Poires",
},
{
    "name" : "Compotes d'abricot",
},
{
    "name" : "Sauces pimentées",
},
{
    "name" : "Poitrine de porc",
},
{
    "name" : "Crèmes UHT",
},
{
    "name" : "Thés à la menthe",
},
{
    "name" : "Poivrons",
},
{
    "name" : "Spéculoos",
},
{
    "name" : "Pralines",
},
{
    "name" : "Sirops d'orange",
},
{
    "name" : "Confitures de tomates",
},
{
    "name" : "Aubergines",
},
{
    "name" : "Crèmes de cassis",
},
{
    "name" : "Muscats",
},
{
    "name" : "Rillettes de crabe",
},
{
    "name" : "Compotes de pêche",
},
{
    "name" : "Crèmes d'artichaut",
},
{
    "name" : "Sorbets à la poire",
},
{
    "name" : "Trempettes",
},
{
    "name" : "Terrines de porc",
},
{
    "name" : "Sorbets au cassis",
},
{
    "name" : "Sauces napolitaines",
},
{
    "name" : "Camomille",
},
{
    "name" : "Patates douces",
},
{
    "name" : "Sorbets à l'abricot",
},
{
    "name" : "Sauces Nuoc-mâm",
},
{
    "name" : "Roquette",
},
{
    "name" : "Clou de girofle",
},
{
    "name" : "Veloutés de champignons",
},
{
    "name" : "Noix de muscade",
},
{
    "name" : "Confitures de goyaves",
},
{
    "name" : "Avoines",
},
{
    "name" : "Sauces bourguignonnes",
},
{
    "name" : "Menthe",
},
{
    "name" : "Confitures de mangues",
},
{
    "name" : "Confitures de groseilles",
},
{
    "name" : "Jus de canneberge",
},
{
    "name" : "Céleri",
},
{
    "name" : "Gins",
},
{
    "name" : "Pastèques",
},
{
    "name" : "Sirops de rose",
},
{
    "name" : "Cerises",
},
{
    "name" : "Confitures de quetsches",
},
{
    "name" : "Sauces au roquefort",
},
{
    "name" : "Confitures de citron",
},
{
    "name" : "Époisses",
},
{
    "name" : "Concombres",
},
{
    "name" : "Nectars de fraise",
},
{
    "name" : "Langoustes",
},
{
    "name" : "Glaces rhum-raisin",
},
{
    "name" : "Purées de brocolis",
},
{
    "name" : "Picodon",
},
{
    "name" : "Sauces indiennes",
},
{
    "name" : "Safran",
},
{
    "name" : "Sauces hollandaise",
},
{
    "name" : "Carpaccio de saumon",
},
{
    "name" : "Nectars de banane",
},
{
    "name" : "Gousses de vanille",
},
{
    "name" : "Gésiers de poulet",
},
{
    "name" : "Truffades",
},
{
    "name" : "Sirops de cerise",
},
{
    "name" : "Fromage de tête",
},
{
    "name" : "Compotes de rhubarbe",
},
{
    "name" : "Glaces à la pistache",
},
{
    "name" : "Veloutés de poireaux",
},
{
    "name" : "Confitures de pommes",
},
{
    "name" : "Sirops de pomme",
},
{
    "name" : "Sauces au beurre blanc",
},
{
    "name" : "Sorbets au citron vert",
},
{
    "name" : "Pintades",
},
{
    "name" : "Sorbets à la pomme",
},
{
    "name" : "Coulis de myrtille",
},
{
    "name" : "Crémant d'Alsace",
},
{
    "name" : "Graines de pavot",
},
{
    "name" : "Citron confit",
},
{
    "name" : "Sorbets à la pêche",
},
{
    "name" : "Terrines de poulet",
},
{
    "name" : "Porc au caramel",
},
{
    "name" : "Taramas au saumon",
},
{
    "name" : "Soupes de carottes",
},
{
    "name" : "Sauces à l'oseille",
},
{
    "name" : "Jus de myrtilles",
},
{
    "name" : "Haricots rouges",
},
{
    "name" : "Coulis d'abricot",
},
{
    "name" : "Porto",
},
{
    "name" : "Sirops de myrtille",
},
{
    "name" : "Confitures de melon",
},
{
    "name" : "Courges Butternut",
},
{
    "name" : "Miso",
},
{
    "name" : "Feuilles de coriandre",
},
{
    "name" : "Sauces bravas",
},
{
    "name" : "Sauces américaines",
},
{
    "name" : "Algues wakame",
},
{
    "name" : "Sirops mojito",
},
{
    "name" : "Salmorejo",
},
{
    "name" : "Sauces Pita",
},
{
    "name" : "Radis noirs",
},
{
    "name" : "Sauces blanches",
},
{
    "name" : "Saucisses de dinde",
},
{
    "name" : "Maquereaux fumés",
},
{
    "name" : "Haricots noirs",
},
{
    "name" : "Diots",
},
{
    "name" : "Glaces au yaourt",
},
{
    "name" : "Purées de sésame blanc",
},
{
    "name" : "Raisins blancs",
},
{
    "name" : "Poivrons rouges",
},
{
    "name" : "Glaces au nougat",
},
{
    "name" : "Saucisses savoyardes",
},
{
    "name" : "Mangues au sirop",
},
{
    "name" : "Sirops cola",
},
{
    "name" : "Foies de lapin",
},
{
    "name" : "Nectarines",
},
{
    "name" : "Sauces carbonara",
},
{
    "name" : "Sirops de châtaignes",
},
{
    "name" : "Glaces à la fraise",
},
{
    "name" : "Compotes de fraise",
},
{
    "name" : "Sirops de céréales",
},
{
    "name" : "Buns (petits pains)",
},
{
    "name" : "Crèmes Chantilly",
},
{
    "name" : "Laurier",
},
{
    "name" : "Navet",
},
{
    "name" : "Rillettes de homard",
},
{
    "name" : "Fricadelles",
},
{
    "name" : "Pains viennois",
},
{
    "name" : "Veloutés d'asperges",
},
{
    "name" : "Sirops de kiwi",
},
{
    "name" : "Confitures de kiwi",
},
{
    "name" : "Sauces à l'huitre",
},
{
    "name" : "Jus de mandarine",
},
{
    "name" : "Jus de betterave",
},
{
    "name" : "Cardamome",
},
{
    "name" : "Orge",
},
{
    "name" : "Jus de pêche",
},
{
    "name" : "Huîtres",
},
{
    "name" : "Sorbets à la mandarine",
},
{
    "name" : "Mélasses",
},
{
    "name" : "Sauces basquaises",
},
{
    "name" : "Sirops d'érable ambrés",
},
{
    "name" : "Kakis",
},
{
    "name" : "Sirops de mangue",
},
{
    "name" : "Sorbets à la mirabelle",
},
{
    "name" : "Salsifis",
},
{
    "name" : "Sauces tandoori",
},
{
    "name" : "Homards",
},
{
    "name" : "Sorbets au melon",
},
{
    "name" : "Aneth",
},
{
    "name" : "Girolles",
},
{
    "name" : "Flocons de blé",
},
{
    "name" : "Truffes",
},
{
    "name" : "Sauces au yaourt",
},
{
    "name" : "Fromages de Corse",
},
{
    "name" : "Sorbets à l'orange",
},
{
    "name" : "Sauces tikka masala",
},
{
    "name" : "Glaces aux noisettes",
},
{
    "name" : "Bars",
},
{
    "name" : "Radis rouges",
},
{
    "name" : "Jus d'abricot",
},
{
    "name" : "Biscotte",
},
{
    "name" : "Jus de mangue",
},
{
    "name" : "Glaces au citron",
},
{
    "name" : "Bourbons",
},
{
    "name" : "Carrés de l'Est",
},
{
    "name" : "Tome des Bauges",
},
{
    "name" : "Sauces armoricaines",
},
{
    "name" : "Algues nori sèches",
},
{
    "name" : "Sauces Madère",
},
{
    "name" : "Tequilas",
},
{
    "name" : "Huiles de maïs",
},
{
    "name" : "Raisins noirs",
},
{
    "name" : "Tartufo (dessert)",
},
{
    "name" : "Morilles",
},
{
    "name" : "Calvados",
},
{
    "name" : "Piments verts",
},
{
    "name" : "Brocciu Corse",
},
{
    "name" : "Purées de céleri-rave",
},
{
    "name" : "Mûres",
},
{
    "name" : "Pomélos",
},
{
    "name" : "Groseilles",
},
{
    "name" : "Raisins secs",
},
{
    "name" : "Fenouils",
},
{
    "name" : "Sauces chien",
},
{
    "name" : "Marjolaine",
},
{
    "name" : "Sauces chasseur",
},
{
    "name" : "Flocons de riz",
},
{
    "name" : "Sirops de maïs",
},
{
    "name" : "Rillettes de langoustine",
},
{
    "name" : "Citronnelle",
},
{
    "name" : "Sirops de pastèque",
},
{
    "name" : "Pleurotes en huître entiers",
},
{
    "name" : "Glaces à la menthe",
},
{
    "name" : "Propolis",
},
{
    "name" : "Rillettes de lapin",
},
{
    "name" : "Sirops de riz",
},
{
    "name" : "Sauces brunes",
},
{
    "name" : "Compotes de prunes",
},
{
    "name" : "Saucisses de canard",
},
{
    "name" : "Confitures d'airelles rouges",
},
{
    "name" : "sauce-algerienne",
},
{
    "name" : "Munster",
},
{
    "name" : "Compotes de mangues",
},
{
    "name" : "Bleu des Causses",
},
{
    "name" : "mashmallow",
},
{
    "name" : "Rillettes de crevette",
},
{
    "name" : "Litchis",
},
{
    "name" : "Rôtis de veau",
},
{
    "name" : "parmesan-rape",
},
{
    "name" : "Purées de haricots verts",
},
{
    "name" : "Poivrons verts",
},
{
    "name" : "Papayes",
},
{
    "name" : "rutabagas",
},
{
    "name" : "Grenades",
},
{
    "name" : "Trompettes des morts",
},
{
    "name" : "Rhubarbes",
},
{
    "name" : "Algues spaghetti de mer",
},
{
    "name" : "Algues kombu",
},
{
    "name" : "Terrines de boudin",
},
{
    "name" : "Glucose",
},
{
    "name" : "Cresson",
},
{
    "name" : "Sauces à la menthe",
},
{
    "name" : "Sauces au vin blanc",
},
{
    "name" : "Courges spaghetti",
},
{
    "name" : "Schnaps",
},
{
    "name" : "Ulves",
},
{
    "name" : "Thés à la vanille",
},
{
    "name" : "nigelle",
},
{
    "name" : "Étoiles de badiane",
},
{
    "name" : "Aspartames",
},
{
    "name" : "Rillettes de sanglier",
},
{
    "name" : "Pamplemousses",
},
{
    "name" : "Cornilles",
},
{
    "name" : "Rillettes de mouton",
},
{
    "name" : "Rillettes de bœuf",
},
{
    "name" : "Dorades",
},
{
    "name" : "Lottes",
},
{
    "name" : "Jalapeño",
},
{
    "name" : "Cassis",
},
{
    "name" : "Saké",
},
{
    "name" : "Sauces bordelaises",
},
{
    "name" : "Jus de prune",
},
{
    "name" : "sauces-marocaines",
},
{
    "name" : "knepfles",
},
{
    "name" : "sauce-bruschetta",
},
{
    "name" : "sauces-au-foie-gras",
},
{
    "name" : "sauces-au-vin",
},
{
    "name" : "petoncles",
},
{
    "name" : "Vinaigres de tomate",
},
{
    "name" : "raiforts",
},
{
    "name" : "focaccias",
},
{
    "name" : "bresse-bleu",
},
{
    "name" : "polentas",
},
{
    "name" : "choziro",
},
{
    "name" : "faluche",
},
{
    "name" : "bonbons-fraise",
},
{
    "name" : "tortilla",
},
{
    "name" : "Poivrons jaunes",
},
{
    "name" : "Choux romanesco",
}]

export default categoryList