let seasonFood = {
    "summer": [
        {
            "name": "Ananas",
        },
        {
            "name": "Avocats",
        },
        {
            "name": "Bananes",
        },
        {
            "name": "Cassis",
        },
        {
            "name": "Cerises",
        },
        {
            "name": "Citrons",
        },
        {
            "name": "Clémentines",
        },
        {
            "name": "Figues",
        },
        {
            "name": "Fraises",
        },
        {
            "name": "Mangues",
        },
        {
            "name": "Melons",
        },
        {
            "name": "Artichauts"
        },
        {
            "name": "Asperges"
        },
        {
            "name": "Aubergines"
        },
        {
            "name": "Betteraves"
        },
        {
            "name": "Brocolis"
        },
        {
            "name": "Carottes"
        },
        {
            "name": "Courgettes"
        },
        {
            "name": "Maïs"
        },
        {
            "name": "Navet"
        },
        {
            "name": "Mozzarella",
        },
        {
            "name": "Camemberts",
        },
        {
            "name": "Beaufort"
        },
        {
            "name": "Mascarpone"
        },
        {
            "name": "Roqueforts"
        },
        {
            "name": "Thons",
        },
        {
            "name": "Saumons",
        },
        {
            "name": "Anchois",
        },
        {
            "name": "Sardines",
        }
    ],
    "winter": [
        {
            "name": "Carottes",
        },
        {
            "name": "Pommes de terre",
        },
        {
            "name": "Endives",
        },
        {
            "name": "Oignons",
        },
        {
            "name": "Poireaux",
        },
        {
            "name": "Épinards",
        },
        {
            "name": "Asperges vertes",
        },
        {
            "name": "Ananas",
        },
        {
            "name": "Avocats",
        },
        {
            "name": "Bananes",
        },
        {
            "name": "Citrons",
        },
        {
            "name": "Pommes",
        },
        {
            "name": "Oranges",
        },
        {
            "name": "Poires",
        },
        {
            "name": "Beaufort",
        },
        {
            "name": "Bries",
        },
        {
            "name": "Munsters",
        },
        {
            "name": "Roqueforts",
        },
        {
            "name": "Bars",
        },
        {
            "name": "Noix de Saint-Jacques",
        }
    ],
    "spring": [
        {
            "name": "Ail",
        },
        {
            "name": "Asperges",
        },
        {
            "name": "Aubergines",
        },
        {
            "name": "Betteraves",
        },
        {
            "name": "Concombres",
        },
        {
            "name": "Radis",
        },
        {
            "name": "Carottes",
        },
        {
            "name": "Haricots verts",
        },
        {
            "name": "Tomates",
        },
        {
            "name": "Kiwis",
        },
        {
            "name": "Mangues",
        },
        {
            "name": "Fraises",
        },
        {
            "name": "Melons",
        },
        {
            "name": "Oranges",
        },
        {
            "name": "Pêches"
        },
        {
            "name": "Sardines"
        },
        {
            "name": "Thons"
        },
        {
            "name": "Noix de Saint-Jacques",
        },
        {
            "name": "Saumons",
        },
        {
            "name": "Anchois",
        },
        {
            "name": "Reblochons",
        },
        {
            "name": "Bries",
        },
        {
            "name": "Munsters",
        },
        {
            "name": "Mozzarella",
        },
    ],
    "autumn": [
        {
            "name": "Bars",
        },
        {
            "name": "Noix de Saint-Jacques",
        },
        {
            "name": "Anchois",
        },
        {
            "name": "Collins",
        },
        {
            "name": "Munsters",
        },
        {
            "name": "Mozzarella",
        },
        {
            "name": "Fromages râpés",
        },
        {
            "name": "Châtaignes",
        },
        {
            "name": "Figues",
        },
        {
            "name": "Dattes",
        },
        {
            "name": "Raisins",
        },
        {
            "name": "Carottes",
        },
        {
            "name": "Figues",
        },
        {
            "name": "Dattes",
        },
        {
            "name": "Raisins",
        },
        {
            "name": "Épinards",
        },
        {
            "name": "Poireaux",
        },
        {
            "name": "Pommes de terre",
        }
    ]
}

export default seasonFood
