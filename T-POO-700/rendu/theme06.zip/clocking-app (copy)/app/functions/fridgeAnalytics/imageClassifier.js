import React, { Component } from 'react';

// const TrainingApi = require("@azure/cognitiveservices-customvision-training");
// const msRest = require("@azure/ms-rest-js");


const trainingKey = "e16e840c866b4fa9ad859d204dce3737";
// const predictionKey = "<your prediction key>";
const projectId = "d8735470-71a5-43bd-aa14-668def302f72";

const endPoint = "https://southcentralus.api.cognitive.microsoft.com/"

// const credentials = new msRest.ApiKeyCredentials({ inHeader: { "Training-key": trainingKey } });
// const trainer = new TrainingApi.TrainingAPIClient(credentials, endPoint);


async function retriveTagAndImageLabelisation (label, path) {
    fetch( endPoint + '/customvision/v3.0/training/projects/' + projectId + '/tags' , {
        method: 'GET',
        headers: {
          'Content-Type': 'application/octet-stream',
          'Training-Key': trainingKey
        },
      })
      .then( (response) => {
        return response.json()
      })
      .then( (tags) => {
        for (let index = 0; index < tags.length; index++) {
            const currentTagLabel = tags[index].name;
            if (currentTagLabel == label) {
                let tag = tags[index];
                imageLabelisation(tag.id, path);
            }
        }
      })
}

async function imageLabelisation (tagId, path) {

    console.log(path)
    fetch( endPoint + '/customvision/v3.2/training/projects/' + projectId + '/images/urls' , {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Training-Key': trainingKey
        },
        body: JSON.stringify({
            images: [
              {
                url: path,
                tagIds: [tagId],
              },
            ],
          }),
      })
      .then( (response) => {
        return response.json()
      })
      .then( (data) => {
        console.log('debug imageLabelisation');
        console.log(data)
      })
}


async function imageClassifier(label, path) {
        

    fetch( endPoint + '/customvision/v3.0/training/projects/' + projectId + '/tags?name=' + label , {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Training-Key': trainingKey
        },
      })
      .then( (response) => {
        return response.json()
      })
      .then( (data) => {
        
        if (data.code ==  'BadRequestTagNameNotUnique') {
            retriveTagAndImageLabelisation(label, path)
            return false
        }
        
        imageLabelisation(data.id, path);
      })
      .catch((error) => {
          console.log(error)
      })

}

export function predictionImage(path) {
        
  fetch( "https://southcentralus.api.cognitive.microsoft.com/customvision/v3.0/Prediction/d1f732ed-4543-412b-9ff9-6c06ef5277d0/classify/iterations/Iteration2/url" , {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Prediction-Key': 'e16e840c866b4fa9ad859d204dce3737'
      },
      body: JSON.stringify({
          url:  'data:image/png;base64,' + path,
        }),
    })
    .then( (response) => {
      return response.json()
    })
    .then( (data) => {
      console.log('debug prediction');
      console.log(data)
    })
}


export default imageClassifier