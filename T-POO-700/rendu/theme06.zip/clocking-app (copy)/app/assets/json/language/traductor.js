export default lang = {
    "en-EN": {
        "createReceipt": {
            "choosePicture": "Choose a photo type png or jpg.",
            "updatePicture": "Modify your image",
            "step": "Step",
            "continue": "Continue",
            "addReceipt": "Add your recipe",
            "description": "Description",
            "photo": "Photo",
            "instructions": "Instructions",
            "chooseCategoryError": "Please choose a category",
            "recipeDifficultyError": "Please enter the difficulty of your recipe",
            "chooseImageError": "Please choose an image",
            "chooseStepError": "Please enter preparation instructions",
            "category": "Category",
            "difficulty": "Difficulty",
            "preparationTime": "Preparation time",
            "numberOfPerson": "Portion",
            "timeInMinute": "Time in minutes",
            "title": "Title",
            "enterTitle": "Enter a title*",
            "ingredientList": "List of ingredients",
            "enterIngredientList": "Enter an ingredient list*",
            "addPicture": "Add a photo",
            "addStep": "Add a step",
            "ending": "Finish",
            "back": "Back"
        },
        "fridgeAnalytic": {
            "codeBarScan": "Scan a barcode",
            "pictureScan": "Take pictures of your fruit and vegetables",
            "write": "To write",
            "validate": "Validate",
            "enterIngredient": "Enter an ingredient",
            "enterIngredientInList": "Enter your ingredient in the list",
            "scanYourFirstProductNow": "Scan your first product now and add it to your ingredients",
            "forProductWithoutBarCode": "For products without a barcode, scan a single product and let the AI find it",
            "searchInstruction": "Click on the magnifying glass to cook the most delicious recipes with your ingredients",
            "cancel": "Cancel",
            "loadMore": "Load more"
        },
        "home": {
            "news": "News",
            "search": "Search",
            "recipeNotFound": "No recipe was found ...",
            "home": "Home",
            "searchRecipe": "Search for a recipe"
        },
        "ingredients": {
            "addProductHere": "Add ingredients here or scan your products to find out what you can cook today!",
            "myFridge": "My Fridge",
            "addIngredient": "Add an ingredient"
        },
        "nutritionalInformation": {
            "nutriScoreNotFill": "Nutri-score not filled in",
            "ofProtein": "of protein",
            "ofSalt": "of salt",
            "ofFiber": "of fibre",
            "ofSugar": "of sugar",
            "ofSaturatedFat": "of saturated fat",
            "ofFat": "de gras",
            "infoFor100": "Nutritional information for 100 g"
        },
        "premiumCode": {
            "wellDone": "Enter your premium code",
            "enterYourPremiumCode": "Enter your code here",
        },
        "receipt": {
            "timeNotFill": "Time not filled in",
            "difficultyNotFill": "Difficulty not filled in",
            "notFill": "Not filled in",
            "ingredients": "Ingredients",
            "ingredients": "Ingredients",
            "youHave": "You have ",
            "isMissing": "Is missing ",
            "requiredIngredients": "Required ingredients",
            "instructions": "Instructions",
            "toDeguste": "To be tasted",
            "step": "Step",
            "ingredientNotFound": "The ingredient is not present in your fridge",
            "ingredientFound": "Ingredient is present in your fridge",
        },
        "receipts": {
            "recipeNotFound": "No recipe was found ...",
            "recipes": "Recipes",
            "ingredient": "Ingredient",
            "ingredients": "Ingredients",
            "youHave": "You have ",
            "allIngredients": "All ingredients",
            "loadMore": "Load more"
        },
        "savedReceipts": {
            "youllRetriveLikedRecipes": "You can find all the recipes you liked here! ",
            "favourites": "Favourites"
        },
        "validationReceiptCreation": {
            "receiptCreation": ""
        },
        "tutorial": {
            "next": "next",
            "pass": "pass",
            "start": "start",
            "vegetablesAndFruits": "Recognition of fruits and vegetables",
            "vegetablesAndFruitsInstruction": "Recognise more than 1000 fruits, vegetables and other products without barcodes",
            "barCode": 'Recognition of products with barcodes',
            "barCodeInstruction": "Recognize more than 1 million products with your barcode! ",
            "search": "Recipe tips",
            "searchInstruction": "Search through 10,000 recipes based on what's in your fridge."
        },
        "navigation": {
            "home": "Home",
            "recipes": "Recipes",
            "scan": "Scan",
            "favourites": "Favourites",
            "fridge": "Fridge",
        },
        "landing": {
            "start": "Start",
            "giveToUnicef": "Donate to UNICEF",
            "presentation": "Your recipe ideas in a scan of your fridge!"
        },
    },
    "en-US": {
        "createReceipt": {
            "choosePicture": "Choose a photo type png or jpg.",
            "updatePicture": "Modify your image",
            "step": "Step",
            "continue": "Continue",
            "addReceipt": "Add your recipe",
            "description": "Description",
            "photo": "Photo",
            "instructions": "Instructions",
            "chooseCategoryError": "Please choose a category",
            "recipeDifficultyError": "Please enter the difficulty of your recipe",
            "chooseImageError": "Please choose an image",
            "chooseStepError": "Please enter preparation instructions",
            "category": "Category",
            "difficulty": "Difficulty",
            "preparationTime": "Preparation time",
            "numberOfPerson": "Portion",
            "timeInMinute": "Time in minutes",
            "title": "Title",
            "enterTitle": "Enter a title*",
            "ingredientList": "List of ingredients",
            "enterIngredientList": "Enter an ingredient list*",
            "addPicture": "Add a photo",
            "addStep": "Add a step",
            "ending": "Finish",
            "back": "Back",
        },
        "validationReceiptCreation": {
            "receiptCreation": "The creation of your recipe has been taken into account",
            "ok": "Ok"
        },
        "fridgeAnalytic": {
            "codeBarScan": "Scan a barcode",
            "pictureScan": "Take pictures of your fruit and vegetables",
            "write": "To write",
            "validate": "Validate",
            "enterIngredient": "Enter an ingredient",
            "enterIngredientInList": "Enter your ingredient in the list",
            "scanYourFirstProductNow": "Scan your first product now and add it to your ingredients",
            "forProductWithoutBarCode": "For products without a barcode, scan a single product and let the AI find it",
            "searchInstruction": "Click on the magnifying glass to cook the most delicious recipes with your ingredients",
            "cancel": "Cancel",
            "loadMore": "Load more"
        },
        "home": {
            "news": "News",
            "search": "Search",
            "recipeNotFound": "No recipe was found ...",
            "home": "Home",
            "searchRecipe": "Search for a recipe"
        },
        "ingredients": {
            "addProductHere": "Add ingredients here or scan your products to find out what you can cook today!",
            "myFridge": "My Fridge",
            "addIngredient": "Add an ingredient"
        },
        "nutritionalInformation": {
            "nutriScoreNotFill": "Nutri-score not filled in",
            "ofProtein": "of protein",
            "ofSalt": "of salt",
            "ofFiber": "of fibre",
            "ofSugar": "of sugar",
            "ofSaturatedFat": "of saturated fat",
            "ofFat": "of fat",
            "infoFor100": "Nutritional information for 100 g"
        },
        "premiumCode": {
            "wellDone": "Enter your premium code",
            "enterYourPremiumCode": "Enter your code here",
        },
        "receipt": {
            "timeNotFill": "Time not filled in",
            "difficultyNotFill": "Difficulty not filled in",
            "notFill": "Not filled in",
            "ingredient": "Ingredient",
            "ingredients": "Ingredients",
            "requiredIngredients": "Required ingredients",
            "instructions": "Instructions",
            "toDeguste": "To be tasted",
            "step": "Step",
            "ingredientNotFound": "The ingredient is not present in your fridge",
            "ingredientFound": "Ingredient is present in your fridge",
        },
        "receipts": {
            "recipeNotFound": "No recipe was found ...",
            "recipes": "Recipes",
            "ingredient": "Ingredient",
            "ingredients": "Ingredients",
            "youHave": "You have ",
            "allIngredients": "All ingredients",
            "loadMore": "Load more"
        },
        "savedReceipts": {
            "youllRetriveLikedRecipes": "You can find all the recipes you liked here! ",
            "favourites": "Favourites"
        },
        "validationReceiptCreation": {
            "receiptCreation": "The creation of your recipe has been taken into account",
            "ok": "Ok"
        },
        "tutorial": {
            "next": "next",
            "pass": "pass",
            "start": "start",
            "vegetablesAndFruits": "Recognition of fruits and vegetables",
            "vegetablesAndFruitsInstruction": "Recognise more than 1000 fruits, vegetables and other products without barcodes",
            "barCode": 'Recognition of products with barcodes',
            "barCodeInstruction": "Recognize more than 1 million products with your barcode! ",
            "search": "Recipe tips",
            "searchInstruction": "Search through 10,000 recipes based on what's in your fridge."
        },
        "navigation": {
            "home": "Home",
            "recipes": "Recipes",
            "scan": "Scan",
            "favourites": "Favourites",
            "fridge": "Fridge",
        },
        "landing": {
            "start": "Start",
            "giveToUnicef": "Donate to UNICEF",
            "presentation": "Your recipe ideas in a scan of your fridge!"
        },
    },
    "fr-FR": {
        "createReceipt": {
            "choosePicture": "Choisir une photo de type png ou jpg.",
            "updatePicture": "Modifier votre image",
            "step": "Étape",
            "continue": "Continuer",
            "addReceipt": "Ajoutez votre recette",
            "description": "Description",
            "photo": "Photo",
            "instructions": "Instructions",
            "chooseCategoryError": "Veuillez choisir une catégorie",
            "recipeDifficultyError": "Veuillez entrer la difficulté de votre recette",
            "chooseImageError": "Veuillez choisir une image",
            "chooseStepError": "Veuillez entrer des instructions de préparations",
            "category": "Catégorie",
            "difficulty": "Difficulté",
            "preparationTime": "Temps de préparation",
            "numberOfPerson": "Nombre de personne",
            "timeInMinute": "Temps en minute",
            "title": "Titre",
            "enterTitle": "Entrer un titre*",
            "ingredientList": "Liste d'ingrédient",
            "enterIngredientList": "Entrer une liste d'ingrédient*",
            "addPicture": "Ajouter une photo",
            "addStep": "Ajouter une étape",
            "ending": "Terminer",
            "back": "Retour",
        },
        "fridgeAnalytic": {
            "codeBarScan": "Scannez un code-barre",
            "pictureScan": "Prenez en photo vos fruits et légumes",
            "write": "Écrire",
            "validate": "Valider",
            "enterIngredient": "Entrer un ingrédient",
            "enterIngredientInList": "Entrez votre ingrédient dans la liste",
            "scanYourFirstProductNow": "Scannez votre premier produit maintenant pour l'ajouter dans vos ingrédients",
            "forProductWithoutBarCode": "Pour les produits sans code-barres, analysez un seul produit et laisser l'IA le trouver",
            "searchInstruction": "Cliquez sur la loupe pour cuisiner avec vos ingrédients les recettes les plus savoureuses",
            "cancel": "Annuler",
            "loadMore": "Voir plus"
        },
        "home": {
            "news": "Nouveautés",
            "search": "Recherche",
            "recipeNotFound": "Aucune recette n'a été trouvé ...",
            "home": "Accueil",
            "searchRecipe": "Rechercher une recette"
        },
        "ingredients": {
            "addProductHere": "Ajoutez des ingrédients ici ou scannez vos produits pour découvrir ce que vous pouvez cuisiner aujourd'hui!",
            "myFridge": "Mon Frigo",
            "addIngredient": "Ajouter un ingrédient"
        },
        "landing": {
            "start": "Démarrer",
            "giveToUnicef": "Faire un don à UNICEF",
            "presentation": "Vos idées recettes en un scan de votre frigo !"
        },
        "nutritionalInformation": {
            "nutriScoreNotFill": "Nutri-score non renseigné",
            "ofProtein": "de protéine",
            "ofSalt": "de sel",
            "ofFiber": "de fibre",
            "ofSugar": "de sucre",
            "ofSaturatedFat": "de gras saturé",
            "ofFat": "de gras",
            "infoFor100": "Repères nutritionnels pour 100 g"
        },
        "premiumCode": {
            "wellDone": "Entrez votre code premium",
            "enterYourPremiumCode": "Entrer votre code ici",
        },
        "receipt": {
            "timeNotFill": "Temps non renseigné",
            "difficultyNotFill": "Difficulté non renseigné",
            "notFill": "Non renseigné",
            "ingredients": "Ingrédients",
            "youHave": "Vous avez ",
            "requiredIngredients": "Ingrédients obligatoires",
            "instructions": "Instructions",
            "toDeguste": "À déguster",
            "step": "Étape",
            "ingredientNotFound": "L'ingrédient n'est pas présent dans votre frigo",
            "ingredientFound": "L'ingrédient est présent dans votre frigo"
        },
        "receipts": {
            "recipeNotFound": "Aucune recette n'a été trouvé ...",
            "recipes": "Recettes",
            "ingredient": "Ingrédient",
            "ingredients": "Ingrédients",
            "youHave": "Vous avez ",
            "isMissing": "Il vous manque ",
            "allIngredients": "Tous les ingrédients",
            "loadMore": "Voir plus"
        },
        "savedReceipts": {
            "youllRetriveLikedRecipes": "Vous pourrez retrouver toutes les recettes que vous avez likées ici ! ",
            "favourites": "Favoris"
        },
        "tutorial": {
            "next": "Suivant",
            "pass": "Passer",
            "start": "Démarrer",
            "vegetablesAndFruits": "Reconnaissance de fruits et de légumes",
            "vegetablesAndFruitsInstruction": "Reconnaissez plus de 1000 fruits, légumes et autres produits sans code-barre !",
            "barCode": 'Reconnaissance de produits avec code-barre',
            "barCodeInstruction": "Reconnaissez plus de 1 millions de produits grâce à vos code-barre ! ",
            "search": "Conseils recettes",
            "searchInstruction": "Recherchez parmi 10 000 recettes, selon ce que votre frigo contient."
        },
        "validationReceiptCreation": {
            "receiptCreation": "La création de votre recette a été prise en compte !",
            "ok": "Ok"
        },
        "navigation": {
            "home": "Home",
            "recipes": "Recettes",
            "scan": "Scan",
            "favourites": "Favories",
            "fridge": "Frigo",
        },
    }
}