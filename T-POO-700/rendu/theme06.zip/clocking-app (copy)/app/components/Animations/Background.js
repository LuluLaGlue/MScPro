import React from "react";
import {
    ImageBackground,
    Image,
    StyleSheet,
    StatusBar,
    Dimensions,
    Linking,
    TouchableHighlight,
    TouchableOpacity
} from "react-native";
import apple1 from "../../assets/imgs/food/apple-1.png"
import apple from "../../assets/imgs/food/apple.png"
import asparagus from "../../assets/imgs/food/asparagus.png"
import aubergine from "../../assets/imgs/food/aubergine.png"
import avocado from "../../assets/imgs/food/avocado.png"
import bacon from "../../assets/imgs/food/bacon.png"
import baguette from "../../assets/imgs/food/baguette.png"
import banana from "../../assets/imgs/food/banana.png"
import beans from "../../assets/imgs/food/beans.png"
import biscuit from "../../assets/imgs/food/biscuit.png"
import blueberries from "../../assets/imgs/food/blueberries.png"
import boiled from "../../assets/imgs/food/boiled.png"
import bowl from "../../assets/imgs/food/bowl.png"
import bread from "../../assets/imgs/food/bread.png"
import broccoli from "../../assets/imgs/food/broccoli.png"
import butcher from "../../assets/imgs/food/butcher.png"
import butter from "../../assets/imgs/food/butter.png"
import cabbage from "../../assets/imgs/food/cabbage.png"
import cake from "../../assets/imgs/food/cake.png"
import can1 from "../../assets/imgs/food/can-1.png"
import can2 from "../../assets/imgs/food/can-2.png"
import chocolate from "../../assets/imgs/food/chocolate.png"
import mushrooms from "../../assets/imgs/food/mushrooms.png"
import mustard1 from "../../assets/imgs/food/mustard-1.png"
import mustard2 from "../../assets/imgs/food/mustard-2.png"
import mustard from "../../assets/imgs/food/mustard.png"
import noodles from "../../assets/imgs/food/noodles.png"
import oat from "../../assets/imgs/food/oat.png"
import octopus from "../../assets/imgs/food/octopus.png"
import oil from "../../assets/imgs/food/oil.png"
import pie from "../../assets/imgs/food/pie.png"
import pineapple from "../../assets/imgs/food/pineapple.png"
import pint from "../../assets/imgs/food/pint.png"
import pistachio from "../../assets/imgs/food/pistachio.png"
import pizza from "../../assets/imgs/food/pizza.png"
import pomegranate from "../../assets/imgs/food/pomegranate.png"
import popsicle from "../../assets/imgs/food/popsicle.png"
import pot1 from "../../assets/imgs/food/pot-1.png"
import radish from "../../assets/imgs/food/radish.png"
import raspberry from "../../assets/imgs/food/raspberry.png"
import watermelon from "../../assets/imgs/food/watermelon.png"
import { Block } from "galio-framework";
import { View } from "react-native-animatable";


const { height, width } = Dimensions.get("screen");

class Background extends React.Component {

    componentWillMount() {
        this.state = {
            'positionTop': [
                10 - this.getRandomInt(300) + 200,
                10 - this.getRandomInt(300) + 200,
                10 - this.getRandomInt(300) + 200,
                10 - this.getRandomInt(300) + 200,
                10 - this.getRandomInt(300) + 200,
                10 - this.getRandomInt(300) + 200,
                10 - this.getRandomInt(300) + 200,
                10 - this.getRandomInt(300) + 200,
                10 - this.getRandomInt(300) + 200,
                10 - this.getRandomInt(300) + 200,
                60 - this.getRandomInt(300) + 200,
                60 - this.getRandomInt(300) + 200,
                60 - this.getRandomInt(300) + 200,
                60 - this.getRandomInt(300) + 200,
                60 - this.getRandomInt(300) + 200,
                60 - this.getRandomInt(300) + 200,
                60 - this.getRandomInt(300) + 200,
                60 - this.getRandomInt(300) + 200,
                60 - this.getRandomInt(300) + 200,
                60 - this.getRandomInt(300) + 200,
                90 - this.getRandomInt(300) + 200,
                90 - this.getRandomInt(300) + 200,
            ],
            'positionLeft': [
                width * 0.0,
                width * 0.20,
                width * 0.30,
                width * 0.40,
                width * 0.50,
                width * 0.60,
                width * 0.70,
                width * 0.80,
                width * 0.90,
                width * 0.95,
                width * 0.10 + 10,
                width * 0.20 + 10,
                width * 0.30 + 10,
                width * 0.40 + 10,
                width * 0.50 + 10,
                width * 0.60 + 10,
                width * 0.70 + 10,
                width * 0.80 + 10,
                width * 0.90 + 10,
                width * 0.15 + 10,
            ]
        }
    }

    componentDidMount() {
        let interval = setInterval(() => {
            this.setState({
                "positionTop": [
                    this.state.positionTop[0] + 0.5,
                    this.state.positionTop[1] + 0.35,
                    this.state.positionTop[2] + 0.5,
                    this.state.positionTop[3] + 0.35,
                    this.state.positionTop[4] + 0.25,
                    this.state.positionTop[5] + 0.5,
                    this.state.positionTop[6] + 0.35,
                    this.state.positionTop[7] + 0.5,
                    this.state.positionTop[8] + 0.35,
                    this.state.positionTop[9] + 0.5,
                    this.state.positionTop[10] + 0.25,
                    this.state.positionTop[11] + 0.5,
                    this.state.positionTop[12] + 0.35,
                    this.state.positionTop[13] + 0.5,
                    this.state.positionTop[14] + 0.25,
                    this.state.positionTop[15] + 0.5,
                    this.state.positionTop[16] + 0.35,
                    this.state.positionTop[17] + 0.5,
                    this.state.positionTop[18] + 0.5,
                    this.state.positionTop[19] + 0.35,
                    this.state.positionTop[20] + 0.25,
                    this.state.positionTop[21] + 0.5,
                ]
            })
        }, 50)

        setTimeout(function (argument) {
            clearInterval(interval);
         },25000);
    }

    getRandomInt(max) {
        return Math.floor(Math.random() * Math.floor(max));
    }

    render() {

        return (
            <Block style={{ position: "absolute", left: 0, width: width }}>
                <Image
                    source={can2}
                    style={{ height: 25, width: 25, zIndex: -1, position: "absolute", top: this.state.positionTop[0] - 100, left: this.state.positionLeft[0] }}
                />
                <Image
                    source={chocolate}
                    style={{ height: 35, width: 35, zIndex: -1, position: "absolute", top: this.state.positionTop[1] - 100, left: this.state.positionLeft[1] }}
                />
                <Image
                    source={mushrooms}
                    style={{ height: 20, width: 20, zIndex: -1, position: "absolute", top: this.state.positionTop[2] - 100, left: this.state.positionLeft[2] }}
                />
                <Image
                    source={mustard}
                    style={{ height: 35, width: 35, zIndex: -1, position: "absolute", top: this.state.positionTop[3] - 100, left: this.state.positionLeft[3] }}
                />
                <Image
                    source={mustard1}
                    style={{ height: 35, width: 35, zIndex: -1, position: "absolute", top: this.state.positionTop[4] - 100, left: this.state.positionLeft[4] }}
                />
                <Image
                    source={mustard2}
                    style={{ height: 20, width: 20, zIndex: -1, position: "absolute", top: this.state.positionTop[5] - 100, left: this.state.positionLeft[5] }}
                />
                <Image
                    source={noodles}
                    style={{ height: 35, width: 35, zIndex: -1, position: "absolute", top: this.state.positionTop[6] - 100, left: this.state.positionLeft[6] }}
                />
                <Image
                    source={oat}
                    style={{ height: 35, width: 35, zIndex: -1, position: "absolute", top: this.state.positionTop[7] - 100, left: this.state.positionLeft[7] }}
                />
                <Image
                    source={octopus}
                    style={{ height: 25, width: 25, zIndex: -1, position: "absolute", top: this.state.positionTop[8] - 100, left: this.state.positionLeft[8] }}
                />
                <Image
                    source={oil}
                    style={{ height: 35, width: 35, zIndex: -1, position: "absolute", top: this.state.positionTop[9] - 100, left: this.state.positionLeft[9] }}
                />
                <Image
                    source={pie}
                    style={{ height: 20, width: 20, zIndex: -1, position: "absolute", top: this.state.positionTop[10] - 100, left: this.state.positionLeft[10] }}
                />
                <Image
                    source={pineapple}
                    style={{ height: 35, width: 35, zIndex: -1, position: "absolute", top: this.state.positionTop[11] - 100, left: this.state.positionLeft[11] }}
                />
                <Image
                    source={pint}
                    style={{ height: 35, width: 35, zIndex: -1, position: "absolute", top: this.state.positionTop[12] - 100, left: this.state.positionLeft[12] }}
                />
                <Image
                    source={pistachio}
                    style={{ height: 20, width: 20, zIndex: -1, position: "absolute", top: this.state.positionTop[13] - 100, left: this.state.positionLeft[13] }}
                />
                <Image
                    source={pizza}
                    style={{ height: 35, width: 35, zIndex: -1, position: "absolute", top: this.state.positionTop[14] - 100, left: this.state.positionLeft[14] }}
                />
                <Image
                    source={pomegranate}
                    style={{ height: 35, width: 35, zIndex: -1, position: "absolute", top: this.state.positionTop[15] - 100, left: this.state.positionLeft[15] }}
                />
                <Image
                    source={popsicle}
                    style={{ height: 25, width: 25, zIndex: -1, position: "absolute", top: this.state.positionTop[16] - 100, left: this.state.positionLeft[16] }}
                />
                <Image
                    source={pot1}
                    style={{ height: 35, width: 35, zIndex: -1, position: "absolute", top: this.state.positionTop[17] - 100, left: this.state.positionLeft[17] }}
                />
                <Image
                    source={radish}
                    style={{ height: 20, width: 20, zIndex: -1, position: "absolute", top: this.state.positionTop[18] - 100, left: this.state.positionLeft[18] }}
                />
                <Image
                    source={cake}
                    style={{ height: 35, width: 35, zIndex: -1, position: "absolute", top: this.state.positionTop[19] - 100, left: this.state.positionLeft[19] }}
                />
                <Image
                    source={apple1}
                    style={{ height: 35, width: 35, zIndex: -1, position: "absolute", top: this.state.positionTop[0], left: this.state.positionLeft[0] }}
                />
                <Image
                    source={apple}
                    style={{ height: 25, width: 25, zIndex: -1, position: "absolute", top: this.state.positionTop[1], left: this.state.positionLeft[1] }}
                />
                <Image
                    source={asparagus}
                    style={{ height: 35, width: 35, zIndex: -1, position: "absolute", top: this.state.positionTop[2], left: this.state.positionLeft[2] }}
                />
                <Image
                    source={aubergine}
                    style={{ height: 35, width: 35, zIndex: -1, position: "absolute", top: this.state.positionTop[3], left: this.state.positionLeft[3] }}
                />
                <Image
                    source={avocado}
                    style={{ height: 20, width: 20, zIndex: -1, position: "absolute", top: this.state.positionTop[4], left: this.state.positionLeft[4] }}
                />
                <Image
                    source={bacon}
                    style={{ height: 35, width: 35, zIndex: -1, position: "absolute", top: this.state.positionTop[5], left: this.state.positionLeft[5] }}
                />
                <TouchableOpacity onPress={() => console.log('debug')} style={{ height: 35, width: 35, zIndex: -10000, position: "absolute", top: this.state.positionTop[20], left: this.state.positionLeft[13] }}>
                    <Image
                        onPress={() => console.log('debug')}
                        source={baguette}
                        style={{ height: 35, width: 35, zIndex: -1, position: "absolute", top: this.state.positionTop[20], left: this.state.positionLeft[20] }}
                    />
                </TouchableOpacity>
                <Image
                    source={banana}
                    style={{ height: 25, width: 25, zIndex: -1, position: "absolute", top: this.state.positionTop[7], left: this.state.positionLeft[7] }}
                />
                <Image
                    source={beans}
                    style={{ height: 35, width: 35, zIndex: -1, position: "absolute", top: this.state.positionTop[8], left: this.state.positionLeft[8] }}
                />
                <Image
                    source={biscuit}
                    style={{ height: 20, width: 20, zIndex: -1, position: "absolute", top: this.state.positionTop[9], left: this.state.positionLeft[9] }}
                />
                <Image
                    source={blueberries}
                    style={{ height: 35, width: 35, zIndex: -1, position: "absolute", top: this.state.positionTop[10], left: this.state.positionLeft[10] }}
                />
                <Image
                    source={boiled}
                    style={{ height: 35, width: 35, zIndex: -1, position: "absolute", top: this.state.positionTop[11], left: this.state.positionLeft[11] }}
                />
                <Image
                    source={bowl}
                    style={{ height: 25, width: 25, zIndex: -1, position: "absolute", top: this.state.positionTop[12], left: this.state.positionLeft[12] }}
                />
                <Image
                    onPress={() => console.log('debug')}
                    source={bread}
                    style={{ height: 35, width: 35, zIndex: -1, position: "absolute", top: this.state.positionTop[13], left: this.state.positionLeft[13] }}
                />
                <Image
                    source={broccoli}
                    style={{ height: 20, width: 20, zIndex: -1, position: "absolute", top: this.state.positionTop[14], left: this.state.positionLeft[14] }}
                />
                <Image
                    source={butcher}
                    style={{ height: 35, width: 35, zIndex: -1, position: "absolute", top: this.state.positionTop[15], left: this.state.positionLeft[15] }}
                />
                <Image
                    source={butter}
                    style={{ height: 35, width: 35, zIndex: -1, position: "absolute", top: this.state.positionTop[16], left: this.state.positionLeft[16] }}
                />
                <Image
                    source={can1}
                    style={{ height: 35, width: 35, zIndex: -1, position: "absolute", top: this.state.positionTop[17], left: this.state.positionLeft[17] }}
                />
                <Image
                    source={cabbage}
                    style={{ height: 20, width: 20, zIndex: -1, position: "absolute", top: this.state.positionTop[18], left: this.state.positionLeft[18] }}
                />
                <Image
                    source={cake}
                    style={{ height: 35, width: 35, zIndex: -1, position: "absolute", top: this.state.positionTop[19], left: this.state.positionLeft[19] }}
                />
            </Block>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: '#ffbd17',
    },
    padded: {
        paddingHorizontal: 10,
        position: "relative",
        zIndex: -2,
    },
    button: {
        width: width - 20,
        height: 10 * 5,
        fontSize: 25,
        shadowRadius: 0,
        shadowOpacity: 0
    },
    logo: {
        width: 80,
        height: 80,
        zIndex: -2,
        position: 'relative',
    },
    title: {
        fontWeight: 'bold',
        marginTop: '-10%',
        textShadowColor: 'rgba(0, 0, 0, 0.25)',
        textShadowOffset: { width: -1, height: 1 },
        textShadowRadius: 10
    },
    titleBlock: {
        fontWeight: 'bold',
        marginTop: '-30%',
    },
    subTitle: {
        fontSize: 30,
        fontWeight: "bold",
        fontFamily: "sans-serif-thin",
        textShadowColor: 'rgba(0, 0, 0, 0.25)',
        textShadowOffset: { width: -1, height: 1 },
        textShadowRadius: 10
    },
    subTitleFirst: {
        marginTop: 220,
        fontSize: 30,
        fontWeight: "bold",
        fontFamily: "sans-serif-thin",
        textShadowColor: 'rgba(0, 0, 0, 0.25)',
        textShadowOffset: { width: -1, height: 1 },
        textShadowRadius: 10
    },
    btnOption: {
        backgroundColor: "#db3236",
        padding: 10,
        fontSize: 25,
        fontWeight: 'bold',
        borderWidth: 1,
        borderRadius: 2,
        borderColor: '#db3236',
        borderBottomWidth: 0,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.8,
        shadowRadius: 2,
        elevation: 3,
        marginLeft: 5,
        marginRight: 5,
        marginTop: 10,
        marginBottom: 70,
        borderRadius: 40,
    },
    btnDonation: {
        position: 'absolute',
        backgroundColor: "#00AEFD",
        padding: 10,
        fontSize: 25,
        fontWeight: 'bold',
        borderRadius: 40,
        borderWidth: 1,
        borderColor: '#00AEFD',
        borderBottomWidth: 0,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.8,
        shadowRadius: 2,
        elevation: 3,
        marginLeft: 5,
        marginRight: 5,
        marginTop: 10,
    },
    btnStart: {
        backgroundColor: "#33A7FC",
        padding: 10,
        fontSize: 25,
        fontWeight: 'bold',
        borderWidth: 1,
        borderRadius: 2,
        borderColor: '#33A7FC',
        borderBottomWidth: 0,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.8,
        shadowRadius: 2,
        elevation: 3,
        marginLeft: 5,
        marginRight: 5,
        marginTop: 30,
        borderRadius: 40,
        width: width * 0.75,
        textAlign: 'center'
    }
});

export default Background;