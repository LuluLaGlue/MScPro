import React, { Component } from 'react';
import { Text } from "galio-framework";
import { Icon } from "react-native-elements";
import { View, StyleSheet, Image, TouchableOpacity, AsyncStorage, Alert } from 'react-native';
import Constants from 'expo-constants';
import { TextInput, Dimensions } from 'react-native';
import Swiper from 'react-native-swiper';
import lang from '../assets/json/language/traductor';
import * as Localization from 'expo-localization';
import profilImage from "../assets/imgs/man.png";
import i18n from 'i18n-js';
import axios from "axios";

// Set the key-value pairs for the different languages you want to support.
i18n.translations = lang
// Set the locale once at the beginning of your app.
i18n.locale = Localization.locale;
// When a value is missing from a language it'll fallback to another language with the key present.
i18n.fallbacks = true;



const { height, width } = Dimensions.get("screen");


export default class Profil extends Component {

  constructor(props) {
    super(props);

    this.state = {
      email: null,
      username: null,
      users: [],
      errors: {
        email: null,
        username: null,
        credentials: []
      },
    }

    this.props.navigation.addListener(
      'didFocus',
      async (payload) => {
        this.setState({
          success: ""
        })
        let userToken = await AsyncStorage.getItem('userToken');
        if (!userToken) {
          this.props.navigation.navigate('Landing');
        } else {
          this.readUser();
        }
      }
    );

  }

  async readUser() {
    let userToken = await AsyncStorage.getItem('userToken');
    let userId = await AsyncStorage.getItem('userId');
    
    fetch("http://192.168.43.199:4000/api/users/" + userId, {
      method: 'GET',
      headers: {
        "Authorization": userToken
      }
    })
      .then((response) => {
        return response.json()
      })
      .then((response) => {
        this.setState({users: response.data});
      })
      .catch((error) => {
        console.log(error);
      });
  }

  renderHeader(color) {
    return (
      <View style={{ display: 'flex', justifyContent: 'center' }}>
        <Image source={profilImage} style={{ height: 100, width: 100, alignSelf: "center", marginTop: 40 }} />
        <TouchableOpacity onPress={async () => {
          await AsyncStorage.removeItem('userToken');
          await AsyncStorage.removeItem('userId');
          await AsyncStorage.removeItem('userRole');
          this.props.navigation.navigate('Landing');
        }}>
          <Icon name="logout" type="material-community" color="white" size={40} style={{ marginLeft: width * 0.80, marginBottom: 80 }} />
        </TouchableOpacity>
      </View>
    )
  }


  renderErrors() {
    if (this.state.errors.credentials != "") {
      return (
        <Text style={styles.errorMessage}> {this.state.errors.credentials} </Text>
      )
    }
  }

  renderSuccess() {
    if (this.state.success != "") {
      return (
        <Text style={styles.successMessage}> {this.state.success} </Text>
      )
    }
  }


  async saveUser(response) {
    await AsyncStorage.setItem('userToken', String(response.data.token));
    await AsyncStorage.setItem('userId', String(response.data.user));
    await AsyncStorage.setItem('userRole', String(response.data.role));
    this.props.navigation.navigate('Scan');
  }

  async updateUser() {

    let form = new FormData();

    form.append("email", this.state.users.email);
    form.append("username", this.state.users.username);

    let userToken = await AsyncStorage.getItem('userToken');
    let userId =  await AsyncStorage.getItem('userId');
    let userRole = await AsyncStorage.getItem('userRole');

    axios
      .put("http://192.168.43.199:4000/api/users/" + userId, form, {
        headers: {
          "Authorization": userToken
        }
      })
      .then((response) => {
        this.setState({
          success: "User updated"
        })
        console.log(response);
      })
      .catch((error) => {
        this.setState({
          errors: {
            credentials: "Username and email can be either invalid or already used"
          }
        })
      });
  }


  render() {

    return (
      <View style={{ backgroundColor: '#656ec4', height: height, marginTop: 60 }}>
        <View style={{ height: 170, width: width, backgroundColor: "#656ec4" }}>
          {this.renderHeader('white')}
        </View>
        <Swiper activeDotColor="#656ec4" style={{ height: height * 0.74, backgroundColor: "#656ec4" }} scrollEnabled={false} showsButtons={false} loop={false} in ref={(swiper) => { this._swiper = swiper; }}>
          <View style={{ ...styles.recipeBox }}>
            {this.renderErrors()}
            {this.renderSuccess()}
            <Text style={styles.boxTitle}>Email</Text>
            <TextInput
              returnKeyType='done'
              value={this.state.users.email}
              style={styles.inputText} placeholder={"Enter your mail"}
              onChangeText={(value) => { this.setState({ users: {
                username: this.state.users.username,
                email: value
              } }) }}
            />

            <Text style={styles.boxTitle}>Username</Text>
            <TextInput
              value={this.state.users.username}
              returnKeyType='done'
              style={styles.inputText} placeholder={"Enter your username"}
              onChangeText={(value) => { this.setState({ users: {
                username: value,
                email: this.state.users.email
              } }) }}
            />

            <TouchableOpacity
              title=""
              style={{ ...styles.btnStart, marginBottom: height * 0.7 }}
              flex
              center
              onPress={() => {
                this.updateUser();
              }}
            >
              <Text style={{ color: 'white', fontWeight: "bold", textAlign: "center", textTransform: "uppercase" }}>
                Udpate
              </Text>
            </TouchableOpacity>
          </View>
        </Swiper>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginTop: Constants.statusBarHeight,
  },
  item: {
    paddingVertical: 20,
    borderBottomColor: "grey",
    borderBottomWidth: 1
  },
  logoStyle: {
    height: 50,
    width: 50,
  },
  inputText: {
    height: 40,
    borderColor: '#F1F1F5',
    borderWidth: 1,
    width: width * 0.75,
    alignSelf: "center",
    height: 60,
    padding: 10,
    fontSize: 20,
    backgroundColor: "#F8F8F8",
    borderRadius: 5
  },
  textArea: {
    height: 200,
    borderColor: '#F1F1F5',
    borderWidth: 1,
    width: width * 0.75,
    alignSelf: "center",
    textAlignVertical: 'top',
    marginTop: 1,
    padding: 10,
    fontSize: 20,
    backgroundColor: "#F8F8F8",
    borderRadius: 5
  },
  title: {
    fontSize: 16,
  },
  boxTitle: {
    fontSize: 15,
    textTransform: 'uppercase',
    fontWeight: "bold",
    marginTop: 30,
    marginBottom: 20,
    textAlign: 'center'
  },
  recipeBox: {
    paddingTop: 20,
    borderRadius: 5,
    textAlign: 'center',
    alignContent: 'center',
    width: width * 0.90,
    marginLeft: width * 0.50 - width * 0.90 / 2,
    backgroundColor: 'white',
    height: height * 0.50,
    zIndex: 100,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,

    elevation: 5,
  },
  autocompleteContainer: {
    marginLeft: 10,
    marginRight: 10,
    marginTop: 20,
    marginBottom: 20,
  },
  errorMessage: {
    padding: 5,
    textAlign: 'center',
    alignSelf: "center",
    marginBottom: 1,
    color: 'rgba(200, 0, 0, 0.8)'
  },
  successMessage: {
    padding: 5,
    textAlign: 'center',
    alignSelf: "center",
    marginBottom: 1,
    color: 'rgba(0, 200, 0, 0.8)'
  },
  itemText: {
    fontSize: 15,
    margin: 2
  },
  descriptionContainer: {
    // `backgroundColor` needs to be set otherwise the
    // autocomplete input will disappear on text input.
    backgroundColor: '#F5FCFF',
    marginTop: 8
  },
  infoText: {
    textAlign: 'center'
  },
  titleText: {
    fontSize: 18,
    fontWeight: '500',
    marginBottom: 10,
    marginTop: 10,
    textAlign: 'center'
  },
  directorText: {
    color: 'grey',
    fontSize: 12,
    marginBottom: 10,
    textAlign: 'center'
  },
  openingText: {
    textAlign: 'center'
  },
  btnStart: {
    backgroundColor: "#656ec4",
    padding: 15,
    fontSize: 15,
    fontWeight: 'bold',
    borderWidth: 1,
    borderRadius: 2,
    borderColor: '#656ec4',
    borderBottomWidth: 0,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 3,
    marginLeft: 5,
    marginRight: 5,
    marginTop: 30,
    marginBottom: 50,
    borderRadius: 5,
    alignSelf: "center",
    width: width * 0.70,
    textAlign: 'center'
  },
  btnStartContinue: {
    backgroundColor: "#656ec4",
    padding: 15,
    fontSize: 15,
    fontWeight: 'bold',
    borderWidth: 1,
    borderRadius: 2,
    borderColor: '#656ec4',
    borderBottomWidth: 0,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 3,
    marginLeft: 5,
    marginRight: 5,
    marginTop: 60,
    borderRadius: 5,
    alignSelf: "center",
    width: width * 0.70,
    textAlign: 'center'
  },
  btnAdd: {
    backgroundColor: "#5cb85c",
    padding: 10,
    fontSize: 15,
    fontWeight: 'bold',
    borderWidth: 1,
    borderRadius: 2,
    borderColor: '#5cb85c',
    borderBottomWidth: 0,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 3,
    marginRight: 5,
    borderRadius: 40,
    width: width * 0.50,
    textAlign: 'center'
  }
});
