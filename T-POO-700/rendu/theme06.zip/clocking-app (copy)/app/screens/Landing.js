import React, { Component } from 'react';
import { Text } from "galio-framework";
import { View, StyleSheet, Image, TouchableOpacity, AsyncStorage, Alert } from 'react-native';
import Constants from 'expo-constants';
import { TextInput, Dimensions } from 'react-native';
import Swiper from 'react-native-swiper';
import lang from '../assets/json/language/traductor';
import * as Localization from 'expo-localization';
import i18n from 'i18n-js';
import axios from "axios";

// Set the key-value pairs for the different languages you want to support.
i18n.translations = lang
// Set the locale once at the beginning of your app.
i18n.locale = Localization.locale;
// When a value is missing from a language it'll fallback to another language with the key present.
i18n.fallbacks = true;



const { height, width } = Dimensions.get("screen");


export default class Login extends Component {

  constructor(props) {
    super(props);

    this.state = {
      email: null,
      password: null,
      errors: {
        email: null,
        password: null,
        credentials: []
      },
    }

    this.props.navigation.addListener(
      'didFocus',
      async (payload) => {
        let userToken = await AsyncStorage.getItem('userToken');
        if (userToken) {
          this.props.navigation.navigate('Scan');
        }
      }
    );
    
  }

  renderHeader(color) {
    return (
      <View>
        <Text style={{ width: width * 0.70, alignSelf: 'center', fontSize: 40, color: color, fontWeight: "400", paddingVertical: 40, textAlign: "center", display: 'flex', justifyContent: 'center', marginBottom: 30 }}>
          Welcome back !
        </Text>
      </View>
    )
  }


  renderErrors() {
    if (this.state.errors.credentials[0] != "") {
      return (
        <Text style={styles.errorMessage}> {this.state.errors.credentials[0]} </Text>
      )
    }
  }


  async saveUser (response) {
    await AsyncStorage.setItem('userToken', String(response.data.token));
    await AsyncStorage.setItem('userId', String(response.data.user));
    await AsyncStorage.setItem('userRole', String(response.data.role));
    this.props.navigation.navigate('Scan');
  }

  loginUser() {

    let form = new FormData();

    form.append("email", this.state.email);
    form.append("password", this.state.password);

    axios
      .post("http://192.168.43.199:4000/api/login", form)
      .then((response) => {
        this.saveUser(response)
      })
      .catch((error) => {
        this.setState({
          errors: {
            credentials: error.response.data.errors['credentials']
          }
        })
      });

  }


  render() {

    return (
      <View style={{ backgroundColor: '#656ec4', height: height, marginTop: 60 }}>
        <View style={{ height: 170, width: width, backgroundColor: "#656ec4" }}>
          {this.renderHeader('white')}
        </View>
        <Swiper activeDotColor="#656ec4" style={{ height: height * 0.74, backgroundColor: "#656ec4" }} scrollEnabled={false} showsButtons={false} loop={false} in ref={(swiper) => { this._swiper = swiper; }}>
          <View style={{ ...styles.recipeBox }}>
            {this.renderErrors()}
            <Text style={styles.boxTitle}>Email</Text>
            <TextInput
              returnKeyType='done'
              style={styles.inputText} placeholder={"Enter your mail"}
              onChangeText={(value) => { this.setState({ email: value }) }}
            />

            <Text style={styles.boxTitle}>Password</Text>
            <TextInput
              returnKeyType='done'
              secureTextEntry={true}
              style={styles.inputText} placeholder={"Enter your password"}
              onChangeText={(value) => { this.setState({ password: value }) }}
            />

            <TouchableOpacity
              title=""
              style={{ ...styles.btnStart, marginBottom: height * 0.7 }}
              flex
              center
              onPress={() => {
                this.loginUser();
              }}
            >
              <Text style={{ color: 'white', fontWeight: "bold", textAlign: "center", textTransform: "uppercase" }}>
                Login
              </Text>
            </TouchableOpacity>
          </View>
        </Swiper>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginTop: Constants.statusBarHeight,
  },
  item: {
    paddingVertical: 20,
    borderBottomColor: "grey",
    borderBottomWidth: 1
  },
  logoStyle: {
    height: 50,
    width: 50,
  },
  inputText: {
    height: 40,
    borderColor: '#F1F1F5',
    borderWidth: 1,
    width: width * 0.75,
    alignSelf: "center",
    height: 60,
    padding: 10,
    fontSize: 20,
    backgroundColor: "#F8F8F8",
    borderRadius: 5
  },
  textArea: {
    height: 200,
    borderColor: '#F1F1F5',
    borderWidth: 1,
    width: width * 0.75,
    alignSelf: "center",
    textAlignVertical: 'top',
    marginTop: 1,
    padding: 10,
    fontSize: 20,
    backgroundColor: "#F8F8F8",
    borderRadius: 5
  },
  title: {
    fontSize: 16,
  },
  boxTitle: {
    fontSize: 15,
    textTransform: 'uppercase',
    fontWeight: "bold",
    marginTop: 30,
    marginBottom: 20,
    textAlign: 'center'
  },
  recipeBox: {
    paddingTop: 20,
    borderRadius: 5,
    textAlign: 'center',
    alignContent: 'center',
    width: width * 0.90,
    marginLeft: width * 0.50 - width * 0.90 / 2,
    backgroundColor: 'white',
    height: height * 0.50,
    zIndex: 100,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,

    elevation: 5,
  },
  autocompleteContainer: {
    marginLeft: 10,
    marginRight: 10,
    marginTop: 20,
    marginBottom: 20,
  },
  errorMessage: {
    alignSelf: "center",
    marginBottom: 1,
    color: 'rgba(200, 0, 0, 0.8)'
  },
  itemText: {
    fontSize: 15,
    margin: 2
  },
  descriptionContainer: {
    // `backgroundColor` needs to be set otherwise the
    // autocomplete input will disappear on text input.
    backgroundColor: '#F5FCFF',
    marginTop: 8
  },
  infoText: {
    textAlign: 'center'
  },
  titleText: {
    fontSize: 18,
    fontWeight: '500',
    marginBottom: 10,
    marginTop: 10,
    textAlign: 'center'
  },
  directorText: {
    color: 'grey',
    fontSize: 12,
    marginBottom: 10,
    textAlign: 'center'
  },
  openingText: {
    textAlign: 'center'
  },
  btnStart: {
    backgroundColor: "#656ec4",
    padding: 15,
    fontSize: 15,
    fontWeight: 'bold',
    borderWidth: 1,
    borderRadius: 2,
    borderColor: '#656ec4',
    borderBottomWidth: 0,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 3,
    marginLeft: 5,
    marginRight: 5,
    marginTop: 30,
    marginBottom: 50,
    borderRadius: 5,
    alignSelf: "center",
    width: width * 0.70,
    textAlign: 'center'
  },
  btnStartContinue: {
    backgroundColor: "#656ec4",
    padding: 15,
    fontSize: 15,
    fontWeight: 'bold',
    borderWidth: 1,
    borderRadius: 2,
    borderColor: '#656ec4',
    borderBottomWidth: 0,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 3,
    marginLeft: 5,
    marginRight: 5,
    marginTop: 60,
    borderRadius: 5,
    alignSelf: "center",
    width: width * 0.70,
    textAlign: 'center'
  },
  btnAdd: {
    backgroundColor: "#5cb85c",
    padding: 10,
    fontSize: 15,
    fontWeight: 'bold',
    borderWidth: 1,
    borderRadius: 2,
    borderColor: '#5cb85c',
    borderBottomWidth: 0,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 3,
    marginRight: 5,
    borderRadius: 40,
    width: width * 0.50,
    textAlign: 'center'
  }
});
