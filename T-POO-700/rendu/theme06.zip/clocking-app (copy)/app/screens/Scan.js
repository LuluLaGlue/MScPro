import React, { Component } from 'react';
import { AsyncStorage, StyleSheet, Text, View, Dimensions, Modal, Image } from 'react-native';
import { Camera } from 'expo-camera';
import { withNavigationFocus } from 'react-navigation';
import BarcodeMask from 'react-native-barcode-mask';
import {Icon} from 'react-native-elements';
import check from "../assets/imgs/check.png";
import close from "../assets/imgs/close.png";


import lang from '../assets/json/language/traductor';
import * as Localization from 'expo-localization';
import i18n from 'i18n-js';

// Set the key-value pairs for the different languages you want to support.
i18n.translations = lang
// Set the locale once at the beginning of your app.
i18n.locale = Localization.locale;
// When a value is missing from a language it'll fallback to another language with the key present.
i18n.fallbacks = true;


const { width, height } = Dimensions.get('window');

class FridgeAnalytic extends Component {

  constructor(props) {
    super(props);

    this.state = {
      hasCameraPermission: null,
      type: Camera.Constants.Type.back,
      showModal: false,
      status: false,
      mode: "barCode",
      ingredients: [],
      frameHeight: 150,
      query: "",
      frameStyle: {
        borderColor: 'red',
        backgroundColor: ''
      }
    };

    this.scannedCode = null;
    this.props.navigation.addListener(
      'didFocus',
      async (payload) => {
        let userToken = await AsyncStorage.getItem('userToken');
        if (!userToken) {
          this.props.navigation.navigate('Landing');
        }
      }
    );
  }

  async componentDidMount() {

    const { status } = await Camera.requestPermissionsAsync();
    await this.setState({ hasCameraPermission: status === 'granted' });

  }

  async _getBarcodeInfo(decode) {
    let userId = await AsyncStorage.getItem('userId');
    let userToken = await AsyncStorage.getItem('userToken');
    let form = new FormData();

    let fullAdress = String(decode + userId);

    if (!this.state.blockModal) {
      fetch(fullAdress, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': userToken
        },
        body: JSON.stringify({}),
      })
      .then((response) => {
        return response.json()
      })
      .then((response) => {
        this.setState({blockModal: true});
        this.setState({status: response.status, showModal: true});
        setTimeout(() => {
          this.setState({blockModal: false});
        }, 3000)
      })
      .catch((error) => {
        console.log(error.response);
      })
    }
  }

  onBarCodeRead(scannedData) {

    let data = scannedData.data;
    let type = scannedData.type;
    this._getBarcodeInfo(data)
  }

  renderBorderMask() {
    return (
      <BarcodeMask height={height / 3} width={height / 3} edgeBorderWidth={2} showAnimatedLine={true} animatedLineOrientation={'vertical'} lineAnimationDuration="1000" outerMaskOpacity={0.8} />
    )
  }
  
  modalIsFound () {

    if (!this.state.status) {
        return (
            <Modal
              animationType="slide"
              transparent={true}
              visible={this.state.showModal}
              style={{ marginTop: height * 0.40 }}
            >
              <Icon
                name='close'
                type='material-community'
                color='#F52D56'
                containerStyle={{
                  position: "absolute", backgroundColor: 'transparent', borderRadius: 100, left: width * 0.80, top: height * 0.07, zIndex: 100
                }}
                size={50}
                onPress={() => this.setState({ 'showModal': false })} />
              <View style={styles.centeredView}>
                <View style={styles.modalView}>
                  <Image source={check} style={{ width: 100, height: 100, borderRadius: 50, alignSelf: 'center', marginTop: 50, zIndex: 2000 }} />
                  <Text style={{ width: width * 0.72, fontSize: 18.5, marginTop: 40, fontWeight: 'bold', textTransform: 'uppercase', textAlign: 'center'}}>Bienvenu !</Text>
                </View>
              </View>
            </Modal>
          )
    } else {
        return (
            <Modal
              animationType="slide"
              transparent={true}
              visible={this.state.showModal}
              style={{ marginTop: height * 0.40 }}
            >
              <Icon
                name='close'
                type='material-community'
                color='#F52D56'
                containerStyle={{
                  position: "absolute", backgroundColor: 'transparent', borderRadius: 100, left: width * 0.80, top: height * 0.07, zIndex: 100
                }}
                size={50}
                onPress={() => this.setState({ 'showModal': false })} />
              <View style={styles.centeredView}>
                <View style={styles.modalView}>
                  <Image source={close} style={{ width: 100, height: 100, borderRadius: 50, alignSelf: 'center', marginTop: 50, zIndex: 2000 }} />
                  <Text style={{ width: width * 0.72, fontSize: 18.5, marginTop: 40, fontWeight: 'bold', textTransform: 'uppercase', textAlign: 'center'}}>À bientôt</Text>
                </View>
              </View>
            </Modal>
          )
    }
  }

  renderFrame() {
    return (
      <View>
        <View style={{ ...styles.barCodeFrame, borderColor: this.state.frameStyle.borderColor, backgroundColor: this.state.frameStyle.backgroundColor }}>
        </View>
      </View>
    );
  }

  render() {
    const { hasCameraPermission } = this.state;
    const isActive = this.props.navigation.isFocused();

    if (hasCameraPermission === null) {
      return <Text></Text>;
    }

    if (hasCameraPermission === false) {
      return <Text>No access to camera</Text>;
    }

    if (isActive === false) {
      return <Text>No access to camera</Text>;
    }

    return (
      <View style={styles.container}>
        {this.modalIsFound()}
        <Camera style={{ position: "absolute", height: height, width: width }} ref={ref => {
          this.camera = ref;
        }} onBarCodeScanned={(obj) => this.onBarCodeRead(obj)} type={this.state.cameraType}>
          {this.renderBorderMask()}
        </Camera>
      </View>
    );
  }
}

export default withNavigationFocus(FridgeAnalytic);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fdc613',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 0,
  },
  barCodeFrame: {
    height: 150,
    width: height / 2.5,
    borderRadius: 3,
    borderColor: "red",
    borderWidth: 1
  },
  loader: {
    height: 30,
    width: 30,
    borderWidth: 1
  },
  preview: {
    flex: 1,
    justifyContent: 'flex-end',
    alignItems: 'center',
  },
  capture: {
    flex: 0,
    backgroundColor: '#fdc613',
    borderRadius: 5,
    padding: 15,
    paddingHorizontal: 20,
    alignSelf: 'center',
    margin: 20,
  },
  titleText: {
    fontSize: 30,
    marginTop: 30,
    color: 'white',
    fontWeight: 'bold'
  },
  productListButton: {
    height: 30,
    width: 30,
    borderRadius: 30
  },
  absoluteFill: {
    height: height
  },
  centeredView: {
    backgroundColor: 'transparent',
    position: "absolute",
    flex: 1,
    marginTop: 50
  },
  centeredView2: {
    position: "absolute",
    marginTop: height * 0.40,
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 22
  },
  itemText: {
    minWidth: '70%'
  },
  modalView: {
    width: width * 0.90,
    height: height * 0.45,
    margin: 20,
    marginTop: 0,
    backgroundColor: "white",
    borderRadius: 20,
    padding: 35,
    paddingTop: 10,
    alignItems: "center",
  },
  modalView2: {
    width: width * 0.90,
    height: height * 0.89,
    margin: 20,
    marginTop: 0,
    backgroundColor: "transparent",
    borderRadius: 20,
    padding: 35,
    paddingTop: 10,
    alignItems: "center",
  },
  imgTuto: {
    flex: 1, height: height * 0.50, width: width * 0.50, resizeMode: 'contain', alignSelf: 'center'
  },
  modalView3: {
    width: width * 0.90,
    margin: 20,
    marginTop: 0,
    backgroundColor: "white",
    borderRadius: 20,
    padding: 35,
    paddingTop: 10,
  },
  openButton: {
    marginTop: 10,
    backgroundColor: "#F194FF",
    borderRadius: 20,
    padding: 15,
    elevation: 2,
    zIndex: 10
  },
  textStyle: {
    color: "white",
    fontWeight: "bold",
    textAlign: "center",
    fontSize: 20
  },
  modalText: {
    marginBottom: 15,
    textAlign: "center"
  },
  autocompleteContainer: {
    paddingLeft: 5,
    paddingRight: 5,
    marginLeft: 10,
    marginRight: 10,
    width: "100%",
    height: 20,
    borderColor: "grey",
    marginTop: height * 0.02,
    marginBottom: height * 0.02,
    borderRadius: 10,
    zIndex: 10000
  },
});
