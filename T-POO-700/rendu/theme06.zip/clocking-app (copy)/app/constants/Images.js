// local imgs
const Onboarding = require("../assets/imgs/bg.png");
const Logo = require("../assets/imgs/argon-logo.png");
const LogoOnboarding = require("../assets/imgs/argon-logo-onboarding.png");
const RegisterBackground = require("../assets/imgs/register-bg.png");
const Pro = require("../assets/imgs/getPro-bg.png");
const ArgonLogo = require("../assets/imgs/argonlogo.png");
const iOSLogo = require("../assets/imgs/ios.png");
const nutriScoreA = require("../assets/imgs/nutriscore/nutriscore-a.jpg");
const nutriScoreB = require("../assets/imgs/nutriscore/nutriscore-b.jpg");
const nutriScoreC = require("../assets/imgs/nutriscore/nutriscore-c.jpg");
const nutriScoreD = require("../assets/imgs/nutriscore/nutriscore-d.jpg");
const nutriScoreE = require("../assets/imgs/nutriscore/nutriscore-e.jpg");
const ingredientsLogo = require("../assets/imgs/ingredients.png");
const receiptsLogo = require("../assets/imgs/book.png");
const healthy = require("../assets/imgs/category/healthy.png");
const sport = require("../assets/imgs/category/sport.png");
const vege = require("../assets/imgs/category/vege.png");
const gourmand = require("../assets/imgs/category/gourmand.png");
const fiber = require("../assets/imgs/nutriscore/fiber.png");
const protein = require("../assets/imgs/nutriscore/protein.png");
const salt = require("../assets/imgs/nutriscore/salt.png");



// internet imgs
const Viewed = [
  'https://images.unsplash.com/photo-1501601983405-7c7cabaa1581?fit=crop&w=240&q=80',
  'https://images.unsplash.com/photo-1543747579-795b9c2c3ada?fit=crop&w=240&q=80',
  'https://images.unsplash.com/photo-1551798507-629020c81463?fit=crop&w=240&q=80',
  'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?fit=crop&w=240&q=80',
  'https://images.unsplash.com/photo-1503642551022-c011aafb3c88?fit=crop&w=240&q=80',
  'https://images.unsplash.com/photo-1482686115713-0fbcaced6e28?fit=crop&w=240&q=80',
];

const Products = {
  'View article': 'https://images.unsplash.com/photo-1501601983405-7c7cabaa1581?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=840&q=840',
};

export default {
  Onboarding,
  Logo,
  LogoOnboarding,
  RegisterBackground,
  Viewed,
  Products,
  Pro,
  ArgonLogo,
  iOSLogo,
  nutriScoreA,
  nutriScoreB,
  nutriScoreC,
  nutriScoreD,
  nutriScoreE,
  ingredientsLogo,
  receiptsLogo,
  fiber,
  protein,
  salt,
  sport,
  vege,
  gourmand,
  healthy
};