import React, { Component } from 'react';
import { Dimensions, Platform } from 'react-native';
import { createStackNavigator } from 'react-navigation-stack';
import { createBottomTabNavigator } from 'react-navigation-tabs';
import { Icon } from 'react-native-elements';

import Profil from './screens/Profil';
import Scan from './screens/Scan';
import Landing from './screens/Landing';
import { StackActions, NavigationActions } from 'react-navigation'

let screen = Dimensions.get('window');
let tintColor = '#656ec4';

import lang from './assets/json/language/traductor';
import * as Localization from 'expo-localization';
import i18n from 'i18n-js';

// Set the key-value pairs for the different languages you want to support.
i18n.translations = lang
// Set the locale once at the beginning of your app.
i18n.locale = Localization.locale;
// When a value is missing from a language it'll fallback to another language with the key present.
i18n.fallbacks = true;


export const AppStack = createStackNavigator({
  'Landing': {
    screen: Landing,
    navigationOptions: ({ navigation }) => ({
      header: null,
      tabBarVisible: true,
      gesturesEnabled: false
    }),
  },
});

export const TabsNavigator = createBottomTabNavigator({
  'Scan': {
    screen: Scan,
    navigationOptions: {
      tabBarVisible: true,
      tabBarLabel: "scan",
      tabBarOptions: {
        activeTintColor: '#656ec4',
      },
      tabBarIcon: ({ tintColor }) => <Icon name="qrcode" type="material-community" size={28} color={tintColor} style={{ marginBottom: 0 }} />
    },
  },
  'Profil': {
    screen: Profil,
    navigationOptions: {
      tabBarVisible: true,
      tabBarLabel: "profil",
      tabBarOptions: {
        activeTintColor: '#656ec4',
      },
      tabBarIcon: ({ tintColor }) => <Icon name="account" type="material-community" size={28} color={tintColor} style={{ marginBottom: 0 }} />
    },
  }
});
