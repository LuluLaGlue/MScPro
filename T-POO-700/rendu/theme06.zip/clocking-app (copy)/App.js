import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { createAppContainer, createSwitchNavigator } from 'react-navigation';
import {TabsNavigator} from './app/router';
import {AppStack} from './app/router';

console.disableYellowBox = true;

export default createAppContainer(createSwitchNavigator(
  {
    AppStack: AppStack,
    TabsNavigator: TabsNavigator
  }
));

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
