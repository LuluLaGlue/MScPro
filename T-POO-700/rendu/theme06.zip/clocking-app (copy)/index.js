import { AppRegistry } from 'react-native';
import App from './App';


// const loadFonts = async () => {
//     await Font.loadAsync({
//         Ubuntu: require('../assets/fonts/Ubuntu-Bold.ttf'),
//     });
// }

// AppRegistry.registerComponent('Font', () => loadFonts());
AppRegistry.registerComponent('App', () => App);
